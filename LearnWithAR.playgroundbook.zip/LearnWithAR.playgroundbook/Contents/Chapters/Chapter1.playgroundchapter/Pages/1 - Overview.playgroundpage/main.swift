/*:
# LearnWithAR: Intro to Electromagnetism
WWDC20 Swift Student Challenge Submission by Jose Adolfo Talactac

## Overview
In this Swift Playground, you will learn about electric charges, Coulomb’s Law, and electric fields through interactive augmented reality experiences.
 
Every page in this Playground can be experienced within 45 seconds or less; however, if you want to go more in-depth, you may take your time experimenting with each **Task** written on each page or browse through the source code. Have fun!
 
## Credits
 - [Overpass Mono font](https://fonts.google.com/specimen/Overpass+Mono) found in the Playground's interface and banner is used under the [Open Font License 1.1](https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL). The font is designed by Delve Withrington of [Delve Fonts](https://delvefonts.com).
 - Avenir Black font found in the Playground's interface is accessed as part of iPadOS' preinstalled system fonts. The font is designed by Adrian Frutiger and licensed by [Linotype](linotype.com).
 - Banner and poster is designed by Jose Adolfo Talactac for use in this Playground.

 - Important:
 This Playgrounds has been tested on iPad Pro 10.5-inch and iPad Pro 12.9-inch (3rd Generation). It may underperform or crash on certain iPad models. Please run this Playgrounds without any video running in Picture-in-Picture or another app running in Split View or Slide Over alongside Swift Playgrounds for a smoother experience.
 
Go to the [Next Page](@next) once you're ready.
*/
