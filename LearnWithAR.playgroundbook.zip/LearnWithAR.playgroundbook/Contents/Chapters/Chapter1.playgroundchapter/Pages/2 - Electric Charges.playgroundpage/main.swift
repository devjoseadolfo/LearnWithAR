/*:
# Electric Charges
An object may possess a positive or a negative electric charge. It can also be neutral.
 
If an atom loses an electron, it will have more positive protons than negative electrons, thus, it will have a positive net charge. If an atom gains an electron, it will have more negative electrons than positive protons, thus, it will have a negative net charge. An atom would be neutral if the number of protons and electrons are equal.
 
Electric charges are measured using the SI unit *C* or *coulombs*. A proton has a charge of `+1.60 × 10⁻¹⁹ coulombs` while an electron has a charge of `-1.60 × 10⁻¹⁹ coulombs`.
*/
let atom: Element = .carbon // You may change the element. You can use .hydrogen, .helium, .lithium, .beryllium, .boron, .carbon, .nitrogen, .oxygen, .fluorine, and .neon
let charge: Int = 0 // You may change the charge. You can make it negative, positive, or zero.
/*:
**Task:** Make Your Own Atom
1. Tap `Run the Code` on the right.
2. Point your camera towards a flat surface. Detect the flat surface.
3. Once the flat surface is detected, tap on the screen where you want the 3D scene to appear.
4. Since `charge` is set to `0`, the atom has the same amount of electons and protons. It is neutral.
5. Try changing `charge` to a negative number, the atom will gain an electron. Look at the right, observe how much coulombs or C the atom has.
6. Now, try changing `charge` to a positive number, it will lose an electron. Observe what happens to how much coulombs or C the atom has.
 
Go to the [Next Page](@next) or browse through the code found below or found in the files in the `Modules` section.
*/
import SceneKit
import ARKit
import PlaygroundSupport

let elementDictionary = staticDictionary.getElement(name: atom.rawValue)
let maxElectron = elementDictionary?["electron"] as! Int

if charge > maxElectron {
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Change the amount of charge assigned to the atom."], solution: "Since \(atom.rawValue) has \(maxElectron) electrons, it cannot have a charge of greater than +\(maxElectron).")
    PlaygroundPage.current.finishExecution()
}

@available(iOSApplicationExtension 13.0, *)
class ViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate {
    let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
    let sceneView = ARSCNView()
    let scene = SCNScene()
    var lastPanPosition: SCNVector3?
    var panStartZ: CGFloat?
    var panningNode: SCNNode?
    var mainNode: SCNNode = SCNNode()
    var isAtomPlaced: Bool = false
    var currentAngleY: Float = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.frame = frame
        sceneView.scene = scene
        sceneView.delegate = self
        sceneView.session.delegate = self
        
        view.addSubview(sceneView)
        
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.session = sceneView.session
        coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
        coachingOverlay.activatesAutomatically = true
        coachingOverlay.goal = .horizontalPlane
        sceneView.addSubview(coachingOverlay)
        
        NSLayoutConstraint.activate([
            coachingOverlay.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            coachingOverlay.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            coachingOverlay.widthAnchor.constraint(equalTo: view.widthAnchor),
            coachingOverlay.heightAnchor.constraint(equalTo: view.heightAnchor)
        ])
        let tapGesure = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handleThePan))
        let rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(rotateNode))
        sceneView.addGestureRecognizer(tapGesure)
        sceneView.addGestureRecognizer(panGesture)
        sceneView.addGestureRecognizer(rotateGesture)
        sceneView.setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        configuration.environmentTexturing = .automatic
        sceneView.autoenablesDefaultLighting = false
        sceneView.automaticallyUpdatesLighting = true
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func addAtomModelTo(position: SCNVector3) {
        self.sceneView.scene.rootNode.enumerateChildNodes { (node, _) in
            if node.name == "base" {
                node.removeFromParentNode()
            }
        }
        
        let shapeNode = atomView().createAtom(element: atom.rawValue, charge: charge, textOn: true)
        
        mainNode.position = position
        mainNode.name = "base"
        
        sceneView.scene.rootNode.addChildNode(mainNode)
        mainNode.addChildNode(shapeNode)
    
    }
    
    func addPlaneTo(node:SCNNode) {
        let plane = SCNPlane(width: 200, height: 200)
        plane.firstMaterial?.colorBufferWriteMask = .init(rawValue: 0)
        let planeNode = SCNNode(geometry: plane)
        planeNode.rotation = SCNVector4Make(1, 0, 0, -Float.pi / 2)
        node.addChildNode(planeNode)
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
    
    @objc func handleTap(gesture: UITapGestureRecognizer) {
        if isAtomPlaced == false {
            let location = gesture.location(in: sceneView)
            guard let hitTestResult = sceneView.hitTest(location, types: .estimatedHorizontalPlane).first else { return }
            let position = SCNVector3Make(hitTestResult.worldTransform.columns.3.x,
                                          hitTestResult.worldTransform.columns.3.y,
                                          hitTestResult.worldTransform.columns.3.z)
            addAtomModelTo(position: position)
            isAtomPlaced = true
        } else {
            if gesture.state == .ended {
                let location: CGPoint = gesture.location(in: sceneView)
                let hits = self.sceneView.hitTest(location, options: nil)
                if let tappednode = hits.first?.node {
                    illuminateNode(node: tappednode)
                }
            }
        }
    }
    @objc func handleThePan(gestureRecognizer: UIPanGestureRecognizer) {
        switch gestureRecognizer.state {
        case .began:
            
            let location = gestureRecognizer.location(in: sceneView)
            guard let hitNodeResult = sceneView.hitTest(location, options: nil).first else { return }
            lastPanPosition = hitNodeResult.worldCoordinates
            panningNode = hitNodeResult.node
            panStartZ = CGFloat(sceneView.projectPoint(lastPanPosition!).z)
        case .changed:
            guard lastPanPosition != nil, panningNode != nil, panStartZ != nil else { return }
            let location = gestureRecognizer.location(in: sceneView)
            
            let worldTouchPosition = sceneView.unprojectPoint(SCNVector3(location.x, location.y, panStartZ!))
            
            let movementVector = SCNVector3(worldTouchPosition.x - lastPanPosition!.x,
                                            0,
                                            (worldTouchPosition.z - lastPanPosition!.z) * 2)
            mainNode.localTranslate(by: movementVector)
            
            self.lastPanPosition = worldTouchPosition
        case .ended:
            (lastPanPosition, panningNode, panStartZ) = (nil, nil, nil)
        default:
            return
        }
    }
    @objc func rotateNode(_ gesture: UIRotationGestureRecognizer){
        let rotation = Float(gesture.rotation)
        
        if gesture.state == .changed{
            
            mainNode.eulerAngles.y = currentAngleY + rotation
        }
        
        if(gesture.state == .ended) {
            currentAngleY = mainNode.eulerAngles.y
            
        }
    }
    func illuminateNode(node: SCNNode) {
        let nodeName = node.name
        if nodeName != nil {
            scene.rootNode.enumerateChildNodes {inode, stop in
                if nodeName == inode.name {
                    shapeCreation().fadeAnimation(node: inode)
                }
            }
        }
    }
}

extension ARSCNView {
    
    func setup() {
        antialiasingMode = .multisampling4X
        automaticallyUpdatesLighting = true
        
        preferredFramesPerSecond = 60
        contentScaleFactor = 1
        
    }
}

if #available(iOSApplicationExtension 13.0, *) {
    PlaygroundPage.current.liveView = ViewController()
} else {
    // Fallback on earlier versions
}
