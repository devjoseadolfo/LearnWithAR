/*:
# Coulomb's Law
A key phrase in electromagnetism is “alike signs repel and opposite signs attract”. What does this mean?

 When two objects have respective net charges that are positive, they will push each other away. If one object has a positive net charge while the other has a negative net charge, they will pull each other in. These pushes and pulls are the forces that charged objects exert on one another.

 The amount of force is measured in the SI unit of *N* or *newtons*. The force can be calculated using the Coulomb’s Law formula:
 
 ![Coulomb's Law Equation](CoulombEquation.png)
 
 *where:*
 - `F` = force *(in newtons)*
 - `k` = Coulomb's constant
 - `q` = charges *(in coulombs)*
 - `r` = distance between charges *(in meters)*
*/
 let atomA: Element = .carbon // Please do not change.
 let chargeOfAtomB: Int = +1 // You may change the charge. You can make it negative, positive, or zero.
 let atomB: Element = .carbon // Please do not change.
 let chargeOfAtomA: Int = +1 // You may change the charge. You can make it negative, positive, or zero.
/*:
 **Task:** Repel and Attract
1. Tap `Run the Code` on the right.
2. Point your camera towards a flat surface. Detect the flat surface.
3. Once the flat surface is detected, tap on the screen where you want the 3D scene to appear.
4. You can tap on an atom to show how much force it exerts on the other atom. Observe where the arrows are pointing at.
5. You can make the spheres farther or nearer each other by dragging an atom to a new location. Observe how the distance affects amount of force they exert.
6. Try changing values of `chargeOfAtomA` and `chargeOfAtomB`. Observe how these values affect the amount of force they exert.
 
Go to the [Next Page](@next) or browse through the code found below or found in the files in the `Modules` section.
*/
import SceneKit
import ARKit
import PlaygroundSupport

if chargeOfAtomA > 6 || chargeOfAtomB > 6 {
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Change the amount assigned for the charges."], solution: "A carbon has six electrons. It cannot have a charge of more than +6.")
    PlaygroundPage.current.finishExecution()
}

@available(iOSApplicationExtension 13.0, *)
class ViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate {
    let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
    let coulomb = coulombView()
    let sceneView = ARSCNView()
    let scene = SCNScene()
    var lastPanPosition: SCNVector3?
    var panStartZ: CGFloat?
    var panningNode: SCNNode?
    var mainNode: SCNNode = SCNNode()
    var isMainPlaced: Bool = false
    var isQ1On: Bool = true
    var currentAngleY: Float = 0.0
    var q1 = SCNNode()
    var q2 = SCNNode()
    var isRemoved = false
    var isMoved = false
    var distance: Float = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.frame = frame
        sceneView.scene = scene
        sceneView.delegate = self
        sceneView.session.delegate = self
        
        view.addSubview(sceneView)
        
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.session = sceneView.session
        coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
        coachingOverlay.activatesAutomatically = true
        coachingOverlay.goal = .horizontalPlane
        sceneView.addSubview(coachingOverlay)
        
        NSLayoutConstraint.activate([
            coachingOverlay.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            coachingOverlay.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            coachingOverlay.widthAnchor.constraint(equalTo: view.widthAnchor),
            coachingOverlay.heightAnchor.constraint(equalTo: view.heightAnchor)
        ])
        let tapGesure = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handleThePan))
        let rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(rotateNode))
        sceneView.addGestureRecognizer(tapGesure)
        sceneView.addGestureRecognizer(panGesture)
        sceneView.addGestureRecognizer(rotateGesture)
        sceneView.setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        configuration.environmentTexturing = .automatic
        sceneView.autoenablesDefaultLighting = false
        sceneView.automaticallyUpdatesLighting = true
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func addAtomModelTo(position: SCNVector3) {
        self.sceneView.scene.rootNode.enumerateChildNodes { (node, _) in
            if node.name == "base" {
                node.removeFromParentNode()
            }
        }
        mainNode = coulomb.createMainNode(charge1: chargeOfAtomA, charge2: chargeOfAtomB)
        addArrowNode(num: 1)
        
        mainNode.position = position
        mainNode.name = "base"
        
        sceneView.scene.rootNode.addChildNode(mainNode)
    }
    
    func addPlaneTo(node:SCNNode) {
        let plane = SCNPlane(width: 200, height: 200)
        plane.firstMaterial?.colorBufferWriteMask = .init(rawValue: 0)
        let planeNode = SCNNode(geometry: plane)
        planeNode.rotation = SCNVector4Make(1, 0, 0, -Float.pi / 2)
        node.addChildNode(planeNode)
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
    
    @objc func handleTap(gesture: UITapGestureRecognizer) {
        if isMainPlaced == false {
            let location = gesture.location(in: sceneView)
            guard let hitTestResult = sceneView.hitTest(location, types: .estimatedHorizontalPlane).first else { return }
            let position = SCNVector3Make(hitTestResult.worldTransform.columns.3.x,
                                          hitTestResult.worldTransform.columns.3.y,
                                          hitTestResult.worldTransform.columns.3.z)
            addAtomModelTo(position: position)
            isMainPlaced = true
        } else {
            let location: CGPoint = gesture.location(in: sceneView)
            let hit = self.sceneView.hitTest(location, options: nil).first
            
            guard gesture.state == .ended else { return }
            
            for parent in parentNodesOf(hit!.node) {
                if parent.name == "charge1" && isQ1On == false {
                    removeArrowNode(num: 1)
                    removeArrowNode(num: 2)
                    addArrowNode(num: 1)
                    isQ1On = true
                }
                if parent.name == "charge2" && isQ1On == true {
                    removeArrowNode(num: 1)
                    removeArrowNode(num: 2)
                    addArrowNode(num: 2)
                    isQ1On = false
                }
            }
        }
    }
    @objc func handleThePan(gestureRecognizer: UIPanGestureRecognizer) {
        switch gestureRecognizer.state {
        case .began:
            
            let location = gestureRecognizer.location(in: sceneView)
            guard let hitNodeResult = sceneView.hitTest(location, options: nil).first else { return }
            lastPanPosition = hitNodeResult.worldCoordinates
            panningNode = hitNodeResult.node
            panStartZ = CGFloat(sceneView.projectPoint(lastPanPosition!).z)
            
        case .changed:
            guard lastPanPosition != nil, panningNode != nil, panStartZ != nil else { return }
            let location = gestureRecognizer.location(in: sceneView)
            let worldTouchPosition = sceneView.unprojectPoint(SCNVector3(location.x, location.y, panStartZ!))
            let movementVector = SCNVector3(worldTouchPosition.x - lastPanPosition!.x,
                                            0,
                                            (worldTouchPosition.z - lastPanPosition!.z))
            var targetNode: SCNNode!
            for target in parentNodesOf(panningNode!) {
                if target.name == "charge1" || target.name == "charge2"{
                    targetNode = target
                    
                    removeArrowNode(num: 1)
                    removeArrowNode(num: 2)
                    
                    isRemoved = true
                    worldTouchPosition
                }
            }
            
            distance = sqrt(pow(movementVector.x, 2) + pow(movementVector.z, 2)) * 2
            
            if 0.25 < (coulomb.getDistance() + distance) {
                targetNode?.localTranslate(by: movementVector)
            }
            
            if targetNode?.name == "charge1" {
                coulomb.atomPosition1 = SCNVector3(targetNode.position.x,
                                                   coulomb.atomPosition1.y,
                                                   targetNode.position.z)
                isMoved = true
            } else if targetNode?.name == "charge2" {
                coulomb.atomPosition2 = SCNVector3(targetNode.position.x,
                                                   coulomb.atomPosition2.y,
                                                   targetNode.position.z)
                isMoved = true
            }
            
            self.lastPanPosition = worldTouchPosition
            
        case .ended:
            if isRemoved == true &&  isMoved == true {
                addArrowNode(num: getNum())
                isRemoved = false
                isMoved = false
            }
            (lastPanPosition, panningNode, panStartZ) = (nil, nil, nil)
            
        default:
            return
        }
    }
    @objc func rotateNode(_ gesture: UIRotationGestureRecognizer){
        let rotation = Float(gesture.rotation)
        
        if gesture.state == .changed{
            
            mainNode.eulerAngles.y = currentAngleY + rotation
        }
        
        if(gesture.state == .ended) {
            currentAngleY = mainNode.eulerAngles.y
            
        }
    }
    
    func removeArrowNode(num: Int) {
        if num == 1 {
            var q1Nodes: [SCNNode] = []
            q1.enumerateChildNodes { (node, stop) in
                q1Nodes.append(node)
            }
            for node in q1Nodes {
                node.removeFromParentNode()
            }
            q1.removeFromParentNode()
        } else {
            var q2Nodes: [SCNNode] = []
            q2.enumerateChildNodes { (node, stop) in
                q2Nodes.append(node)
            }
            for node in q2Nodes {
                node.removeFromParentNode()
            }
            q2.removeFromParentNode()
        }
    }
    
    
    func addArrowNode(num: Int) {
        if num == 1 {
            coulomb.q1Node(node: q1)
            mainNode.addChildNode(q1)
        } else {
            coulomb.q2Node(node: q2)
            mainNode.addChildNode(q2)
        }
    }
    
    func parentNodesOf(_ node: SCNNode) -> [SCNNode] {
        if let parentNode = node.parent
        {
            if parentNode is SCNScene
            {
                return []
            }
            else
            {
                return [parentNode] + parentNodesOf(parentNode)
            }
        }
        else
        {
            return []
        }
    }
    
    public func getNum() -> Int{
        var num = 0
        if isQ1On == true{
            num = 1
        } else {
            num = 2
        }
        return num
    }
    
}

extension ARSCNView {
    
    func setup() {
        antialiasingMode = .multisampling4X
        automaticallyUpdatesLighting = true
        
        preferredFramesPerSecond = 60
        contentScaleFactor = 1
        
    }
}

if #available(iOSApplicationExtension 13.0, *) {
    PlaygroundPage.current.liveView = ViewController()
} else {
    // Fallback on earlier versions
}
