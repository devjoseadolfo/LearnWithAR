/*:
# Electric Field - Part 1
Electric fields surround a charge. Electric fields are also vector fields, therefore, they show the directions in which the charge exert energy.

In the electric field, there are the source charges and the test charge. The source charges exert an amount and direction of force onto the test charge, depending on how near the two are and how strong the source charge is. The test charge does not exert any force on the source charge.
*/
let sourceCharge: Float = +1 //in nanocoulombs. Freely change this to any value.
let testCharge: Float = +1 //in nanocoulombs. Test charges can only have a positive charge.
/*:
 **Task:** The Source and The Test
1. Tap `Run the Code` on the right.
Point your camera towards a flat surface. Detect the flat surface.
2. Once the flat surface is detected, tap on the screen where you want the 3D scene to appear.
3. The `sourceCharge` is the one at the center of the screen and the `testCharge` is the green positive symbol with an arrow.
4. You can drag the `sourceCharge` and `testCharge` around to move them to another location. Observe what happens when to the `testCharge`'s vector when it’s closer to the `sourceCharge`.
5. Experiment by changing the amount of `sourceCharge` or by changing the amount of `testCharge`.
 
Go to the [Next Page](@next) or you may browse through the code found below or in the files in the `Modules` section.
*/
import SceneKit
import ARKit
import PlaygroundSupport

if testCharge <= 0 {
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Change the amount assigned for the test charge."], solution: "A test charge can only be a positive number.")
    PlaygroundPage.current.finishExecution()
}
@available(iOSApplicationExtension 13.0, *)
class ViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate {
    let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
    let field = fieldView1()
    let sceneView = ARSCNView()
    let scene = SCNScene()
    var currentAngleY: Float = 0.0
    var lastPanPosition: SCNVector3?
    var panStartZ: CGFloat?
    var panningNode: SCNNode?
    var arrowNodesArray: [SCNNode] = []
    var arrowNodesAngles: [SCNVector3] = []
    var sourceChargeNode: SCNNode!
    var testChargeNode: SCNNode!
    var sourcePosition: SCNVector3!
    var testPosition: SCNVector3!
    var targetNode: SCNNode?
    var postDistance: Float?
    var testArrowNode = SCNNode()
    var isMoved = false
    var isScenePlaced = false
    var mainNode = SCNNode()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.frame = frame
        sceneView.scene = scene
        sceneView.delegate = self
        sceneView.session.delegate = self
        
        view.addSubview(sceneView)
        
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.session = sceneView.session
        coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
        coachingOverlay.activatesAutomatically = true
        coachingOverlay.goal = .horizontalPlane
        sceneView.addSubview(coachingOverlay)
        
        NSLayoutConstraint.activate([
            coachingOverlay.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            coachingOverlay.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            coachingOverlay.widthAnchor.constraint(equalTo: view.widthAnchor),
            coachingOverlay.heightAnchor.constraint(equalTo: view.heightAnchor)
        ])
        let tapGesure = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handleThePan))
        let rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(rotateNode))
        sceneView.addGestureRecognizer(tapGesure)
        sceneView.addGestureRecognizer(panGesture)
        sceneView.addGestureRecognizer(rotateGesture)
        sceneView.setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        configuration.environmentTexturing = .automatic
        sceneView.autoenablesDefaultLighting = false
        sceneView.automaticallyUpdatesLighting = true
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
    
    @objc func handleTap(gesture: UITapGestureRecognizer) {
        if isScenePlaced == false {
            let location = gesture.location(in: sceneView)
            guard let hitTestResult = sceneView.hitTest(location, types: .estimatedHorizontalPlane).first else { return }
            let position = SCNVector3Make(hitTestResult.worldTransform.columns.3.x,
                                          hitTestResult.worldTransform.columns.3.y,
                                          hitTestResult.worldTransform.columns.3.z)
            mainNode.position = position
            mainNode.addChildNode(field.createCamera())
            mainNode.addChildNode(placeSourceCharge())
            mainNode.addChildNode(placeTestCharge())
            mainNode.addChildNode(createFieldArrowCollection())
            if sourceCharge != 0 {
                mainNode.addChildNode(placeTestArrow())
            }
            shapeCreation().createInvisiblePlane(node: mainNode)
            scene.rootNode.addChildNode(mainNode)
            isScenePlaced = true
        }
    }
    
    @objc func handleThePan(gestureRecognizer: UIPanGestureRecognizer) {
        switch gestureRecognizer.state {
        case .began:
            
            let location = gestureRecognizer.location(in: sceneView)
            guard let hitNodeResult = sceneView.hitTest(location, options: nil).first else { return }
            lastPanPosition = hitNodeResult.worldCoordinates
            panningNode = hitNodeResult.node
            panStartZ = CGFloat(sceneView.projectPoint(lastPanPosition!).z)
            
        case .changed:
            guard lastPanPosition != nil, panningNode != nil, panStartZ != nil else { return }
            let location = gestureRecognizer.location(in: sceneView)
            let worldTouchPosition = sceneView.unprojectPoint(SCNVector3(location.x, location.y, panStartZ!))
            let movementVector = SCNVector3(worldTouchPosition.x - lastPanPosition!.x,
                                            0,
                                            (worldTouchPosition.z - lastPanPosition!.z))
            if panningNode?.categoryBitMask == 2 {
                panningNode = sourceChargeNode
                isMoved = true
            } else if panningNode?.categoryBitMask == 4 {
                panningNode = testChargeNode
                isMoved = true
            } else {
                panningNode = nil
            }
            
            panningNode?.localTranslate(by: movementVector)
            
            if isMoved == true && sourceCharge != 0{
                removeTestArrow()
                testPosition = testChargeNode.position
                mainNode.addChildNode(placeTestArrow())
            }
            
            for arrowNode in arrowNodesArray {
                let newAngle = getArrowAngle(arrow: arrowNode)
                arrowNode.eulerAngles = SCNVector3Make(0.0, newAngle, 0.0)
                let opacity = CGFloat(getArrowOpacity(arrow: arrowNode))
                if opacity != 0 {
                    arrowNode.opacity = opacity
                    arrowNode.isHidden = false
                } else {
                    arrowNode.isHidden = true
                }
            }
            
            self.lastPanPosition = worldTouchPosition
            
        case .ended:
            isMoved = false
            (lastPanPosition, panningNode, panStartZ) = (nil, nil, nil)
            
        default:
            return
        }
    }
    @objc func rotateNode(_ gesture: UIRotationGestureRecognizer){
        let rotation = Float(gesture.rotation)
        
        if gesture.state == .changed{
            scene.rootNode.eulerAngles.y = currentAngleY + rotation
        }
        
        if(gesture.state == .ended) {
            currentAngleY = scene.rootNode.eulerAngles.y
        }
    }
    func createFieldArrowCollection() -> SCNNode{
        let arrowCollectionNode = SCNNode()
        
        let xStartCoordinate: Float = -0.75
        let zStartCoordinate: Float = -0.75
        
        for i in 1 ... 16 {
            let a = Float(i - 1)
            for i in 1 ... 16 {
                let arrowNode = SCNNode()
                let b = Float(i - 1)
                arrowNode.addChildNode(field.createFieldArrow(length: 0.075, color: UIColor(red: 0.15, green: 0.15, blue: 0.15, alpha: 1.0), isRepel: true))
                arrowNode.position.x = xStartCoordinate + (0.1 * a)
                arrowNode.position.z = zStartCoordinate + (0.1 * b)
                arrowCollectionNode.addChildNode(arrowNode)
                arrowNodesArray.append(arrowNode)
                let newAngle = getArrowAngle(arrow: arrowNode)
                arrowNode.eulerAngles = SCNVector3Make(0.0, newAngle, 0.0)
                arrowNode.opacity = CGFloat(getArrowOpacity(arrow: arrowNode))
            }
        }
        arrowCollectionNode.position.y = 0.01
        if sourceCharge <= 0 {
            arrowCollectionNode.opacity = 1
        }
        arrowCollectionNode.enumerateHierarchy{ (node, stop) in
            node.categoryBitMask = Category.other.rawValue
        }
        return arrowCollectionNode
    }
    
    func placeSourceCharge() -> SCNNode{
        let shapeNode = SCNNode()
        if sourceCharge == 0 {
            shapeNode.addChildNode(field.createNeutralCharge(scale: 2))
        } else if sourceCharge > 0 {
            shapeNode.addChildNode(field.createPositiveCharge(scale: 2, emit: sourceCharge, isTest: false))
        } else {
            shapeNode.addChildNode(field.createNegativeCharge(scale: 2, emit: -sourceCharge))
        }
        
        sourceChargeNode = shapeNode
        sourceChargeNode.position.y = 0.035
        sourceChargeNode.categoryBitMask = Category.source.rawValue
        sourceChargeNode.enumerateHierarchy{ (node, stop) in
            node.categoryBitMask = Category.source.rawValue
        }
        sourcePosition = sourceChargeNode.position
        return sourceChargeNode
    }
    
    func  placeTestCharge() -> SCNNode{
        let shapeNode = SCNNode()
        shapeNode.addChildNode(field.createPositiveCharge(scale: 2, emit: testCharge, isTest: true))
        testChargeNode = shapeNode
        testChargeNode.position = SCNVector3Make(0.2, 0.035, 0.2)
        testChargeNode.categoryBitMask = Category.test.rawValue
        testChargeNode.enumerateHierarchy{ (node, stop) in
            node.categoryBitMask = Category.test.rawValue
        }
        testPosition = testChargeNode.position
        return testChargeNode
    }
    
    func placeTestArrow() -> SCNNode{
        let length = getLength()
        let arrowNode = field.createFieldArrow(length: length, color: UIColor.green, isRepel: true)
        arrowNode.localTranslate(by:SCNVector3Make(0.04 + (length / 2), 0, 0))
        testArrowNode.addChildNode(arrowNode)
        testArrowNode.position = testChargeNode.position
        let angle = getArrowAngle(arrow: testChargeNode)
        testArrowNode.eulerAngles = SCNVector3Make(0.0, angle, 0.0)
        
        return testArrowNode
    }
    
    func removeTestArrow() {
        var arrowsNodes: [SCNNode] = []
        testArrowNode.enumerateChildNodes { (node, stop) in
            arrowsNodes.append(node)
        }
        for node in arrowsNodes {
            node.removeFromParentNode()
        }
    }
    
    func getLength() -> Float{
        let p1x: Float = sourceChargeNode.position.x
        let p1y: Float = -(sourceChargeNode.position.z)
        let p2x: Float = testPosition.x
        let p2y: Float = -(testPosition.z)
        
        let a1 = simd_float2(p2x - p1x, p2y - p1y)
        
        let d1 = length(a1)
        
        let a1N = normalize(a1)
        
        let m1 = sourceCharge / pow(d1, 2)
        
        let length = abs(m1 / 128)
        
        return length
    }
    
    func getArrowOpacity(arrow: SCNNode) -> Float{
        let p1x: Float = sourceChargeNode.position.x
        let p1y: Float = -(sourceChargeNode.position.z)
        let p2x: Float = arrow.position.x
        let p2y: Float = -(arrow.position.z)
        
        let a1 = simd_float2(p2x - p1x, p2y - p1y)
        
        let d1 = length(a1)
        
        let a1N = normalize(a1)
        
        let m1 = sourceCharge / pow(d1, 2)
        
        let finalOpacity: Float = abs(m1 / 16)
        
        return finalOpacity
    }
    
    func getArrowAngle(arrow: SCNNode) -> Float {
        let p1x: Float = sourceChargeNode.position.x
        let p1y: Float = -(sourceChargeNode.position.z)
        let p2x: Float = arrow.position.x
        let p2y: Float = -(arrow.position.z)
        
        let a1 = simd_float2(p2x - p1x, p2y - p1y)
        
        let d1 = length(a1)
        
        let m1 = sourceCharge / pow(d1, 2)
        
        let Rx = ((a1.x) * m1)
        let Ry = ((a1.y) * m1)
        
        let final = atan2f(Ry, Rx)
        
        return final
    }
}

extension ARSCNView {
    
    func setup() {
        antialiasingMode = .multisampling4X
        automaticallyUpdatesLighting = true
        
        preferredFramesPerSecond = 60
        contentScaleFactor = 1
        
    }
}

if #available(iOSApplicationExtension 13.0, *) {
    PlaygroundPage.current.liveView = ViewController()
} else {
    // Fallback on earlier versions
}

