/*:
# Electric Field - Part 2
Wonder how electric fields look like when there are two source charges? Let’s find out and experiment!
*/
let sourceCharge1: Float = +1 //in nanocoulombs. Freely change this to any value.
let sourceCharge2: Float = -1 //in nanocoulombs. Freely change this to any value.
let testCharge: Float = +1 //in nanocoulombs. Test charges can only have a positive charge.
/*:
**Task:** Two Sources and The Test
1. Tap `Run the Code` on the right.
2. Point your camera towards a flat surface. Detect the flat surface.
3. Once the flat surface is detected, tap on the screen where you want the 3D scene to appear.
4. Experiment by changing the amount of `sourceCharge1` and `sourceCharge2` or by changing the amount `testCharge`.
5. This is the last page, so have fun!
 
This is the last page. If you wish, you may browse through the code found below or found in files in the `Modules` section.
*/
import SceneKit
import ARKit
import PlaygroundSupport

if testCharge <= 0 {
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Change the amount assigned for the test charge."], solution: "A test charge can only be a positive number.")
    PlaygroundPage.current.finishExecution()
}

@available(iOSApplicationExtension 13.0, *)
class ViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate {
    let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
    let field = fieldView1()
    let sceneView = ARSCNView()
    let scene = SCNScene()
    var currentAngleY: Float = 0.0
    var lastPanPosition: SCNVector3?
    var panStartZ: CGFloat?
    var panningNode: SCNNode?
    var arrowNodesArray: [SCNNode] = []
    var arrowNodesAngles: [SCNVector3] = []
    var sourceCharge1Node: SCNNode!
    var sourceCharge2Node: SCNNode!
    var testChargeNode: SCNNode!
    var targetNode: SCNNode?
    var testPosition: SCNVector3!
    var postDistance: Float?
    var testArrowNode = SCNNode()
    var isMoved = false
    var isScenePlaced = false
    var mainNode = SCNNode()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.frame = frame
        sceneView.scene = scene
        sceneView.delegate = self
        sceneView.session.delegate = self
        
        view.addSubview(sceneView)
        
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.session = sceneView.session
        coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
        coachingOverlay.activatesAutomatically = true
        coachingOverlay.goal = .horizontalPlane
        sceneView.addSubview(coachingOverlay)
        
        NSLayoutConstraint.activate([
            coachingOverlay.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            coachingOverlay.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            coachingOverlay.widthAnchor.constraint(equalTo: view.widthAnchor),
            coachingOverlay.heightAnchor.constraint(equalTo: view.heightAnchor)
        ])
        let tapGesure = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handleThePan))
        let rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(rotateNode))
        sceneView.addGestureRecognizer(tapGesure)
        sceneView.addGestureRecognizer(panGesture)
        sceneView.addGestureRecognizer(rotateGesture)
        sceneView.setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        configuration.environmentTexturing = .automatic
        sceneView.autoenablesDefaultLighting = false
        sceneView.automaticallyUpdatesLighting = true
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
    
    @objc func handleTap(gesture: UITapGestureRecognizer) {
        if isScenePlaced == false {
            let location = gesture.location(in: sceneView)
            guard let hitTestResult = sceneView.hitTest(location, types: .estimatedHorizontalPlane).first else { return }
            let position = SCNVector3Make(hitTestResult.worldTransform.columns.3.x,
                                          hitTestResult.worldTransform.columns.3.y,
                                          hitTestResult.worldTransform.columns.3.z)
            mainNode.position = position
            mainNode.addChildNode(field.createCamera())
            mainNode.addChildNode(placeSourceCharge1())
            mainNode.addChildNode(placeSourceCharge2())
            mainNode.addChildNode(placeTestCharge())
            mainNode.addChildNode(createFieldArrowCollection())
            if sourceCharge1 != 0 || sourceCharge2 != 0 {
                mainNode.addChildNode(placeTestArrow())
            }
            shapeCreation().createInvisiblePlane(node: mainNode)
            scene.rootNode.addChildNode(mainNode)
            isScenePlaced = true
        }
    }
    
    @objc func handleThePan(gestureRecognizer: UIPanGestureRecognizer) {
        switch gestureRecognizer.state {
        case .began:
            
            let location = gestureRecognizer.location(in: sceneView)
            guard let hitNodeResult = sceneView.hitTest(location, options: nil).first else { return }
            lastPanPosition = hitNodeResult.worldCoordinates
            panningNode = hitNodeResult.node
            panStartZ = CGFloat(sceneView.projectPoint(lastPanPosition!).z)
            
        case .changed:
            guard lastPanPosition != nil, panningNode != nil, panStartZ != nil else { return }
            let location = gestureRecognizer.location(in: sceneView)
            let worldTouchPosition = sceneView.unprojectPoint(SCNVector3(location.x, location.y, panStartZ!))
            let movementVector = SCNVector3(worldTouchPosition.x - lastPanPosition!.x,
                                            0,
                                            (worldTouchPosition.z - lastPanPosition!.z))
            if panningNode?.categoryBitMask == 2 {
                panningNode = sourceCharge1Node
                isMoved = true
            } else if panningNode?.categoryBitMask == 4 {
                panningNode = testChargeNode
                isMoved = true
            } else if panningNode?.categoryBitMask == 16{
                panningNode = sourceCharge2Node
                isMoved = true
            } else {
                panningNode = nil
            }
            
            panningNode?.localTranslate(by: movementVector)
            
            for arrowNode in arrowNodesArray {
                let newAngle = getArrowAngle(arrow: arrowNode)
                arrowNode.eulerAngles = SCNVector3Make(0.0, newAngle, 0.0)
                let opacity = CGFloat(getArrowOpacity(arrow: arrowNode))
                if opacity != 0 {
                    arrowNode.opacity = opacity
                    arrowNode.isHidden = false
                } else {
                    arrowNode.isHidden = true
                }
            }
            
            if isMoved == true && (sourceCharge1 != 0 || sourceCharge2 != 0) {
                removeTestArrow()
                testPosition = testChargeNode.position
                mainNode.addChildNode(placeTestArrow())
            }
            
            self.lastPanPosition = worldTouchPosition
            
        case .ended:
            isMoved = false
            (lastPanPosition, panningNode, panStartZ) = (nil, nil, nil)
            
        default:
            return
        }
    }
    @objc func rotateNode(_ gesture: UIRotationGestureRecognizer){
        let rotation = Float(gesture.rotation)
        
        if gesture.state == .changed{
            scene.rootNode.eulerAngles.y = currentAngleY + rotation
        }
        
        if(gesture.state == .ended) {
            currentAngleY = scene.rootNode.eulerAngles.y
        }
    }
    func createFieldArrowCollection() -> SCNNode{
        let arrowCollectionNode = SCNNode()
        
        let xStartCoordinate: Float = -0.75
        let zStartCoordinate: Float = -0.75
        
        for i in 1 ... 16 {
            let a = Float(i - 1)
            for i in 1 ... 16 {
                let arrowNode = SCNNode()
                let b = Float(i - 1)
                arrowNode.addChildNode(field.createFieldArrow(length: 0.075, color: UIColor(red: 0.15, green: 0.15, blue: 0.15, alpha: 1.0), isRepel: true))
                arrowNode.position.x = xStartCoordinate + (0.1 * a)
                arrowNode.position.z = zStartCoordinate + (0.1 * b)
                arrowCollectionNode.addChildNode(arrowNode)
                arrowNodesArray.append(arrowNode)
                let newAngle = getArrowAngle(arrow: arrowNode)
                arrowNode.eulerAngles = SCNVector3Make(0.0, newAngle, 0.0)
                arrowNode.opacity = CGFloat(getArrowOpacity(arrow: arrowNode))
            }
        }
        arrowCollectionNode.position.y = 0.01
        if sourceCharge1 <= 0 {
            arrowCollectionNode.opacity = 1
        }
        arrowCollectionNode.enumerateHierarchy{ (node, stop) in
            node.categoryBitMask = Category.other.rawValue
        }
        return arrowCollectionNode
    }
    
    func placeSourceCharge1() -> SCNNode{
        let shapeNode = SCNNode()
        if sourceCharge1 == 0 {
            shapeNode.addChildNode(field.createNeutralCharge(scale: 2))
        } else if sourceCharge1 > 0 {
            shapeNode.addChildNode(field.createPositiveCharge(scale: 2, emit: sourceCharge1, isTest: false))
        } else {
            shapeNode.addChildNode(field.createNegativeCharge(scale: 2, emit: -sourceCharge1))
        }
        
        sourceCharge1Node = shapeNode
        sourceCharge1Node.position = SCNVector3Make(-0.2, 0.035, 0)
        sourceCharge1Node.categoryBitMask = Category.source.rawValue
        sourceCharge1Node.enumerateHierarchy{ (node, stop) in
            node.categoryBitMask = Category.source.rawValue
        }
        
        return sourceCharge1Node
    }
    
    func placeSourceCharge2() -> SCNNode{
        let shapeNode = SCNNode()
        if sourceCharge2 == 0 {
            shapeNode.addChildNode(field.createNeutralCharge(scale: 2))
        } else if sourceCharge2 > 0 {
            shapeNode.addChildNode(field.createPositiveCharge(scale: 2, emit: sourceCharge2, isTest: false))
        } else {
            shapeNode.addChildNode(field.createNegativeCharge(scale: 2, emit: -sourceCharge2))
        }
        
        sourceCharge2Node = shapeNode
        sourceCharge2Node.position = SCNVector3Make(0.2, 0.035, 0)
        sourceCharge2Node.categoryBitMask = Category.source2.rawValue
        sourceCharge2Node.enumerateHierarchy{ (node, stop) in
            node.categoryBitMask = Category.source2.rawValue
        }
        
        return sourceCharge2Node
    }
    
    func  placeTestCharge() -> SCNNode{
        let shapeNode = SCNNode()
        shapeNode.addChildNode(field.createPositiveCharge(scale: 2, emit: testCharge, isTest: true))
        testChargeNode = shapeNode
        testChargeNode.position = SCNVector3Make(0.2, 0.035, 0.2)
        testChargeNode.categoryBitMask = Category.test.rawValue
        testChargeNode.enumerateHierarchy{ (node, stop) in
            node.categoryBitMask = Category.test.rawValue
        }
        testPosition = testChargeNode.position
        return testChargeNode
    }
    
    func placeTestArrow() -> SCNNode{
        let length = getLength()
        let arrowNode = field.createFieldArrow(length: length, color: UIColor.green, isRepel: true)
        arrowNode.localTranslate(by:SCNVector3Make(0.04 + (length / 2), 0, 0))
        testArrowNode.position = testChargeNode.position
        testArrowNode.addChildNode(arrowNode)
        let angle = getArrowAngle(arrow: testChargeNode)
        testArrowNode.eulerAngles = SCNVector3Make(0.0, angle, 0.0)
        return testArrowNode
    }
    
    func removeTestArrow() {
        var arrowsNodes: [SCNNode] = []
        testArrowNode.enumerateChildNodes { (node, stop) in
            arrowsNodes.append(node)
        }
        for node in arrowsNodes {
            node.removeFromParentNode()
        }
        testArrowNode.removeFromParentNode()
    }
    
    func getLength() -> Float{
        let p1x: Float = sourceCharge1Node.position.x - sourceCharge1Node.position.x
        let p1y: Float = -(sourceCharge2Node.position.z - sourceCharge2Node.position.z)
        let p2x: Float = (testPosition.x - sourceCharge1Node.position.x)
        let p2y: Float = -(testPosition.z - sourceCharge1Node.position.z)
        let p3x: Float = (testPosition.x - sourceCharge2Node.position.x)
        let p3y: Float = -(testPosition.z - sourceCharge2Node.position.z)
        
        let a1 = simd_float2(p1x, p1y)
        let a2 = simd_float2(p2x, p2y)
        let a3 = simd_float2(p3x, p3y)
        
        let d1 = distance(a1, a2)
        let d2 = distance(a1, a3)
        
        let m1 = sourceCharge1 / pow(d1, 2)
        let m2 = sourceCharge2 / pow(d2, 2)
        
        let length = sqrt(pow(m1, 2) + pow(m2, 2)) / 128
        
        return length
    }
    
    func getArrowOpacity(arrow: SCNNode) -> Float{
        let p1x: Float = sourceCharge1Node.position.x - sourceCharge1Node.position.x
        let p1y: Float = -(sourceCharge2Node.position.z - sourceCharge2Node.position.z)
        let p2x: Float = (arrow.position.x - sourceCharge1Node.position.x)
        let p2y: Float = -(arrow.position.z - sourceCharge1Node.position.z)
        let p3x: Float = (arrow.position.x - sourceCharge2Node.position.x)
        let p3y: Float = -(arrow.position.z - sourceCharge2Node.position.z)
        
        let a1 = simd_float2(p1x, p1y)
        let a2 = simd_float2(p2x, p2y)
        let a3 = simd_float2(p3x, p3y)
        
        let d1 = distance(a1, a2)
        let d2 = distance(a1, a3)
        
        let m1 = abs(sourceCharge1 / pow(d1, 2))
        let m2 = abs(sourceCharge2 / pow(d2, 2))
        
        var finalOpacity: Float = (m1 + m2) / 16
        
        return finalOpacity
    }
    
    func getArrowAngle(arrow: SCNNode) -> Float {
        let p1x: Float = sourceCharge1Node.position.x - sourceCharge1Node.position.x
        let p1y: Float = -(sourceCharge2Node.position.z - sourceCharge2Node.position.z)
        let p2x: Float = (arrow.position.x - sourceCharge1Node.position.x)
        let p2y: Float = -(arrow.position.z - sourceCharge1Node.position.z)
        let p3x: Float = (arrow.position.x - sourceCharge2Node.position.x)
        let p3y: Float = -(arrow.position.z - sourceCharge2Node.position.z)
        
        let a1 = simd_float2(p1x, p1y)
        let a2 = simd_float2(p2x, p2y)
        let a3 = simd_float2(p3x, p3y)
        
        let d1 = distance(a1, a2)
        let d2 = distance(a1, a3)
        
        let m1 = sourceCharge1 / pow(d1, 2)
        let m2 = sourceCharge2 / pow(d2, 2)
        
        let a2N = normalize(a2)
        let a3N = normalize(a3)
        
        let Rx = ((a2N.x) * m1) + ((a3N.x) * m2)
        let Ry = ((a2N.y) * m1) + ((a3N.y) * m2)
        
        let final = atan2f(Ry, Rx)
        
        return final
    }
}

extension ARSCNView {
    
    func setup() {
        antialiasingMode = .multisampling4X
        automaticallyUpdatesLighting = true
        
        preferredFramesPerSecond = 60
        contentScaleFactor = 1
        
    }
}

if #available(iOSApplicationExtension 13.0, *) {
    PlaygroundPage.current.liveView = ViewController()
} else {
    // Fallback on earlier versions
}
