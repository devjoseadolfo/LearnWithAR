import UIKit
import SceneKit
import SpriteKit

public class atomView {
    let generateShape = shapeCreation() 
    var electricCharge: Int = 0
    var elementName: String = ""
    var elementElectronCount: Int = 0
    var countDifference: Int = 0
    
    public init() {
    }
    
    public func createCamera() -> SCNNode{
        var cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0.0, y: 0.25, z: 4)
        
        return cameraNode
    }
    
    public func createAtom(element: String, charge: Int, textOn: Bool)  -> SCNNode {
        elementName = element 
        electricCharge = charge
        
        let elementDictionary = staticDictionary.getElement(name: element)
        elementElectronCount = elementDictionary?["electron"] as! Int + (charge * -1)
        
        let mainNode = SCNNode()
        mainNode.name = "mainNode"
        mainNode.scale = SCNVector3Make(0.5, 0.5, 0.5)
        createElectrons(node: mainNode)
        createProtons(node: mainNode)
        createNeutrons(node: mainNode)
        generateShape.createLighting(node: mainNode)
        generateShape.createInvisiblePlane(node: mainNode)
        if textOn == true{
            collectTexts(node: mainNode)
        }
        
        return mainNode
    }
    
    public func collectTexts(node: SCNNode) {
        let collectionNode = SCNNode()
        addText(node: collectionNode)
        addTitleCard(node: collectionNode)
        addInfoCardProtons(node: collectionNode)
        addInfoCardElectrons(node: collectionNode)
        addInfoCardNeutrons(node: collectionNode)
        addInfoCardQ(node: collectionNode)
        
        if elementElectronCount > 10 {
            collectionNode.position = SCNVector3Make(0.45, 0, 0.2666666)
        } else if elementElectronCount > 2 {
            collectionNode.position = SCNVector3Make(0.4, 0, 0.2333333)
        } else {
            collectionNode.position = SCNVector3Make(0.35, 0, 0.2)
        }
        
        collectionNode.eulerAngles = SCNVector3Make(-(.pi)/7, -.pi/8, 0.0)
        node.addChildNode(collectionNode)
    }
    
    
    public func createElectrons(node: SCNNode) {
        var electronsNode = SCNNode()
        electronsNode.name = "electronGroup"
        electronsNode.position = SCNVector3Make(0, 0.35, 0)
        
        let firstOrbitElectrons = SCNNode()
        let secondOrbitElectrons = SCNNode()
        let thirdOrbitElectrons = SCNNode()
        
        
        let firstOrbit = generateShape.createOrbit(radius: 0.25)
        firstOrbit.eulerAngles = SCNVector3Make(0, 0, .pi/3)
        let secondOrbit = generateShape.createOrbit(radius: 0.30)
        secondOrbit.eulerAngles = SCNVector3Make(.pi/3, 0, 0)
        let thirdOrbit = generateShape.createOrbit(radius: 0.35)
        thirdOrbit.eulerAngles = SCNVector3Make(.pi/3, .pi/3, 0)
        electronsNode.addChildNode(firstOrbit)
        
        
        if elementElectronCount > 0 {
            for i in 1 ... elementElectronCount {
                let electronShapeNode = generateShape.createSphere(particleName: "electron")
                
                if i < 3 {
                    let n = i
                    var x = elementElectronCount
                    if elementElectronCount > 2 { 
                        x = 2
                    }
                    let rotateUnit = ((2 * Float.pi)/Float(x)) * Float(n)
                    electronShapeNode.pivot = SCNMatrix4MakeTranslation(0.25, 0.0, 0.0)
                    electronShapeNode.eulerAngles = SCNVector3Make(0.0, rotateUnit, 0.0)
                    firstOrbitElectrons.addChildNode(electronShapeNode)
                } else if i < 11 {
                    let n = i - 2
                    var x = elementElectronCount - 2
                    if elementElectronCount > 10 { 
                        x = 8
                    }
                    let rotateUnit = ((2 * Float.pi)/Float(x)) * Float(n)
                    electronShapeNode.pivot = SCNMatrix4MakeTranslation(0.30, 0.0, 0.0)
                    electronShapeNode.eulerAngles = SCNVector3Make(0.0, rotateUnit, 0.0)
                    secondOrbitElectrons.addChildNode(electronShapeNode)
                } else if i < 19 {
                    let n = i - 10
                    var x = elementElectronCount - 10
                    if elementElectronCount > 18{ 
                        x = 18
                    }
                    let rotateUnit = ((2 * Float.pi)/Float(x)) * Float(n)
                    electronShapeNode.pivot = SCNMatrix4MakeTranslation(0.35, 0.0, 0.0)
                    electronShapeNode.eulerAngles = SCNVector3Make(0.0, rotateUnit, 0.0)
                    thirdOrbitElectrons.addChildNode(electronShapeNode)
                }
                
            }
        }
        
        firstOrbit.addChildNode(firstOrbitElectrons)
        secondOrbit.addChildNode(secondOrbitElectrons)
        thirdOrbit.addChildNode(thirdOrbitElectrons)
        
        if elementElectronCount > 2{
            electronsNode.addChildNode(secondOrbit)
        }
        if elementElectronCount > 10 {
            electronsNode.addChildNode(thirdOrbit)
        }
        
        firstOrbitElectrons.runAction(generateShape.orbitAnimation(duration: 8))
        secondOrbitElectrons.runAction(generateShape.orbitAnimation(duration: 10))
        thirdOrbitElectrons.runAction(generateShape.orbitAnimation(duration: 12))
        electronsNode.runAction(generateShape.orbitAnimation(duration: 18))
        
        node.addChildNode(electronsNode)
    }
    
    public func createProtons(node: SCNNode) {
        let elementDictionary = staticDictionary.getElement(name: elementName)
        
        let protonsNode = SCNNode()
        protonsNode.position = SCNVector3Make(0, 0.35, 0)
        protonsNode.name = "protons"
        let protonCount = elementDictionary?["proton"] as! Int
        
        let protonsPositions = elementDictionary?["protonPositions"] as! Array<String>
        var isSetA = elementDictionary?["isDefault"] as! Bool
        
        for i in 0 ... (protonCount - 1){
            let protonShapeNode = generateShape.createSphere(particleName: "proton")
            let position = staticDictionary.getCoordinates(isDefault: isSetA, code: protonsPositions[i]) 
            protonShapeNode.position = position ?? SCNVector3Zero
            protonsNode.addChildNode(protonShapeNode)
        }
        
        node.addChildNode(protonsNode)
    }
    
    public func createNeutrons(node: SCNNode) {
        let elementDictionary = staticDictionary.getElement(name: elementName)
        
        let neutronsNode = SCNNode() 
        neutronsNode.position = SCNVector3Make(0, 0.35, 0)
        neutronsNode.name = "neutrons"
        let neutronCount = elementDictionary?["neutron"] as! Int
        
        if neutronCount != 0 {
            let neutronsPositions = elementDictionary?["neutronPositions"] as! Array<String>
            var isSetA = elementDictionary?["isDefault"] as! Bool
            
            for i in 0 ... (neutronCount - 1){
                let neutronShapeNode = generateShape.createSphere(particleName: "neutron")
                let position = staticDictionary.getCoordinates(isDefault: isSetA, code: neutronsPositions[i]) 
                neutronShapeNode.position = position ?? SCNVector3Zero
                neutronsNode.addChildNode(neutronShapeNode)
            }
        }
        node.addChildNode(neutronsNode)
    }
    
    public func addText(node: SCNNode) {
        let elementDictionary = staticDictionary.getElement(name: elementName)
        let symbol = elementDictionary?["symbol"] as! String
        
        let symbolText = generateShape.createTextShape(string: symbol, size: 1)
        
        let symbolTextNode = SCNNode(geometry: symbolText)
        let max, min: SCNVector3
        max = symbolTextNode.boundingBox.max
        min = symbolTextNode.boundingBox.min
        symbolTextNode.pivot = SCNMatrix4MakeTranslation(
            min.x + (max.x - min.x)/2,
            min.y + (max.y - min.y)/2,
            min.z + (max.z - min.z)/2
        )
        symbolTextNode.scale = SCNVector3(0.1, 0.1, 0.1)
        symbolTextNode.position = SCNVector3(0, 0.05, 0.0)
        
        var chargeString = String(electricCharge)
        
        if electricCharge > 1 {
            chargeString = "+" + chargeString 
        } else if electricCharge == -1 {
            chargeString = "-" 
        } else if electricCharge == 1 {
            chargeString = "+" 
        } 
        
        let chargeText = generateShape.createTextShape(string: chargeString, size: 0.5)
        let chargeTextNode = SCNNode(geometry: chargeText)
        let cmax, cmin: SCNVector3
        cmax = chargeTextNode.boundingBox.max
        cmin = chargeTextNode.boundingBox.min
        chargeTextNode.pivot = SCNMatrix4MakeTranslation(
            cmin.x + (cmax.x - cmin.x)/2,
            cmin.y + (cmax.y - cmin.y)/2,
            cmin.z + (cmax.z - cmin.z)/2
        )
        chargeTextNode.position = SCNVector3Make(((max.x + cmax.x) / 2 * 0.1), symbolTextNode.position.y + 0.025, ((max.z - min.z) * 0.1 / 2) + symbolTextNode.position.z) 
        chargeTextNode.scale = SCNVector3(0.1, 0.1, 0.1)
        
        var particleName: String = ""
        
        if electricCharge == 0 {
            particleName = "neutron"
        } else if electricCharge > 0 {
            particleName = "proton"
        } else {
            particleName = "electron"
        }
        
        symbolText.firstMaterial? = generateShape.createTextMaterial(particleName: particleName)
        chargeText.firstMaterial? = generateShape.createTextMaterial(particleName: particleName)
        
        let textNode = SCNNode()
        textNode.addChildNode(symbolTextNode)
        textNode.position = SCNVector3(0, 0.45, 0)
        if electricCharge != 0 {
            textNode.addChildNode(chargeTextNode)
            textNode.position = SCNVector3(-(symbolTextNode.position.x + chargeTextNode.position.x) / 3, 0.45, 0)
        }
        node.addChildNode(textNode)
    }
    
    public func addTitleCard(node: SCNNode){
        let plane = SCNPlane(width: 0.28, height: 0.06)
        plane.firstMaterial? = generateShape.createCardMaterial()
        plane.firstMaterial?.diffuse.contents = titleContents()
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles = SCNVector3Make(0.0, 0.0, 0.0)
        planeNode.position = SCNVector3Make(0, 0.425, 0.0)
        planeNode.castsShadow = false
        node.addChildNode(planeNode)
    }
    
    public func titleContents() -> SKScene{
        let elementDictionary = staticDictionary.getElement(name: elementName)
        let elementCounts = [elementDictionary?["proton"], elementDictionary?["neutron"], elementElectronCount]
        
        var particleName = ""
        
        if electricCharge == 0 {
            particleName = "neutron"
        } else if electricCharge > 0 {
            particleName = "proton"
        } else {
            particleName = "electron"
        }
        let particleDictionary = staticDictionary.getParticle(name: particleName)
        
        let skScene = SKScene(size:CGSize(width: 700, height: 150))
        skScene.backgroundColor = UIColor.clear
        
        let shape = SKShapeNode(rect: CGRect(x: 0, y: 0, width: skScene.frame.size.width, height: skScene.frame.size.height))
        
        shape.fillColor = particleDictionary?["color"] as! UIColor
        shape.strokeColor = UIColor.clear
        shape.path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: skScene.frame.size.width, height: skScene.frame.size.height), cornerRadius: 25).cgPath
        skScene.addChild(shape)
        
        let label = generateShape.createLabel(string: elementName, 
                                              size: 108, 
                                              color: UIColor.white, 
                                              position: CGPoint(x: shape.frame.size.width / 2, y: shape.frame.size.height / 2))
        skScene.addChild(label)
        
        return skScene
    }
    public func addInfoCardProtons(node: SCNNode){
        let infoCard = SCNNode()
        
        let plane = SCNPlane(width: 0.24, height: 0.06)
        plane.firstMaterial? = generateShape.createCardMaterial()
        plane.firstMaterial?.diffuse.contents = infoContents(particleName: "proton")
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles = SCNVector3Make(0.0, 0.0, 0.0)
        planeNode.position = SCNVector3Make(0, 0.275, 0.0)
        planeNode.castsShadow = false
        
        infoCard.addChildNode(planeNode)
        
        let particleNode = generateShape.createSphere(particleName: "proton")
        particleNode.position = SCNVector3Make(-0.09, 0.275, 0.0)
        infoCard.addChildNode(particleNode)
        
        node.addChildNode(infoCard)
    }
    
    public func addInfoCardElectrons(node: SCNNode){
        let infoCard = SCNNode()
        
        let plane = SCNPlane(width: 0.24, height: 0.06)
        plane.firstMaterial? = generateShape.createCardMaterial()
        plane.firstMaterial?.diffuse.contents = infoContents(particleName: "electron")
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles = SCNVector3Make(0.0, 0.0, 0.0)
        planeNode.position = SCNVector3Make(0, 0.205, 0.0)
        planeNode.castsShadow = false
        
        infoCard.addChildNode(planeNode)
        
        let particleNode = generateShape.createSphere(particleName: "electron")
        particleNode.position = SCNVector3Make(-0.09, 0.205, 0.0)
        infoCard.addChildNode(particleNode)
        
        node.addChildNode(infoCard)
    }
    
    public func addInfoCardNeutrons(node: SCNNode){
        let infoCard = SCNNode()
        
        let plane = SCNPlane(width: 0.24, height: 0.06)
        plane.firstMaterial? = generateShape.createCardMaterial()
        plane.firstMaterial?.diffuse.contents = infoContents(particleName: "neutron")
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles = SCNVector3Make(0.0, 0.0, 0.0)
        planeNode.position = SCNVector3Make(0, 0.135, 0.0)
        planeNode.castsShadow = false
        
        infoCard.addChildNode(planeNode)
        
        let particleNode = generateShape.createSphere(particleName: "neutron")
        particleNode.position = SCNVector3Make(-0.09, 0.135, 0.0)
        infoCard.addChildNode(particleNode)
        
        node.addChildNode(infoCard)
    }
    
    public func infoContents(particleName: String) -> SKScene{
        let elementDictionary = staticDictionary.getElement(name: elementName)
        let elementCounts: Dictionary<String, String> = [
            "proton": String(elementDictionary?["proton"] as! Int), 
            "neutron": String(elementDictionary?["neutron"] as! Int), 
            "electron": String(elementElectronCount)]
        let particleDictionary = staticDictionary.getParticle(name: particleName)
        let particleCount = elementCounts[particleName]!
        
        let skScene = SKScene(size:CGSize(width: 600, height: 150))
        skScene.backgroundColor = UIColor.clear
        
        let base = SKSpriteNode()
        base.size = skScene.size
        base.color = UIColor.white
        base.position = CGPoint(x: skScene.frame.size.width / 2, y: skScene.frame.size.height / 2)
        
        let crec = SKShapeNode()
        crec.fillColor = particleDictionary?["color"] as! UIColor
        crec.strokeColor = UIColor.clear
        crec.path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: skScene.frame.size.width, height: skScene.frame.size.height), cornerRadius: 100).cgPath
        
        let overlay = SKCropNode()
        overlay.maskNode = base
        crec.addChild(overlay)
        
        let mask = SKShapeNode()
        mask.path = UIBezierPath(roundedRect: CGRect(x: 10, y: 10, width: 250, height: skScene.frame.size.height - 20), cornerRadius: 75).cgPath
        mask.fillColor = SKColor.white
        mask.strokeColor = SKColor.clear
        mask.blendMode = .replace
        mask.alpha = 0.01
        crec.addChild(mask)
        skScene.addChild(crec)
        
        
        let particleLabel = generateShape.createLabel(string: elementName, 
                                                      size: 48, 
                                              color: UIColor.white,
                                              position: CGPoint(x: (base.frame.size.width / 2) - 20, y: base.frame.size.height / 2))
        particleLabel.horizontalAlignmentMode = .left
        var paricleLabelStr = String.uppercased(particleName)()
        if elementCounts[particleName] != "1" {
            particleLabel.text = paricleLabelStr + "S"
        } else {
            particleLabel.text = paricleLabelStr
        }
        skScene.addChild(particleLabel)
        
        let countLabel = generateShape.createLabel(string: particleCount, 
                                                   size: 72, 
                                                   color: particleDictionary?["color"] as! UIColor, 
                                                   position: CGPoint(x: 175, y: base.frame.size.height / 2))
        skScene.addChild(countLabel)
        
        return skScene
    }
    
    public func addInfoCardQ(node: SCNNode){
        let qCard = SCNNode()
        
        let plane = SCNPlane(width: 0.20, height: 0.04)
        plane.firstMaterial? = generateShape.createCardMaterial()
        plane.firstMaterial?.diffuse.contents = chargeContents()
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles = SCNVector3Make(0.0, 0.0, 0.0)
        planeNode.position = SCNVector3Make(0.04, 0.35, 0.0)
        planeNode.castsShadow = false
        qCard.addChildNode(planeNode)
        
        let chargeNode = SCNNode()
        if countDifference > 0 {
            chargeNode.addChildNode(generateShape.createPositiveChargeMini())
        } else if countDifference < 0 {
            chargeNode.addChildNode(generateShape.createNegativeChargeMini())
        } else {
            chargeNode.addChildNode(generateShape.createNeutralChargeMini())
        }
        
        chargeNode.position = SCNVector3Make(-0.10, 0.35, 0.0)
        qCard.addChildNode(chargeNode)
        
        node.addChildNode(qCard)
    }
    
    public func chargeContents() -> SKScene{
        var particleName = ""
        if electricCharge == 0 {
             particleName = "neutron"
        } else if electricCharge > 0 {
             particleName = "proton"
        } else {
             particleName = "electron"
        }
        let particleDictionary = staticDictionary.getParticle(name: particleName)
        
        let elementDictionary = staticDictionary.getElement(name: elementName)
        let protonCount = elementDictionary?["proton"] as! Int
        countDifference = protonCount - elementElectronCount
        let q = Double(countDifference) * 0.00000000000000000016021766341
        
        let formatter = NumberFormatter()
        formatter.numberStyle = .scientific
        formatter.positiveFormat = "+0.#E{+0}"
        formatter.negativeFormat = "-0.###E{-0}"
        formatter.exponentSymbol = " × 10^{"
        formatter.usesSignificantDigits = true
        formatter.maximumSignificantDigits = 2
        var qString = formatter.string(for: q)! + "}"
        qString = "q = " + qString.superscripted() + " C"
        if countDifference == 0 {
            qString = "NEUTRAL CHARGE"
        }
        let skScene = SKScene(size:CGSize(width: 510, height: 110))
        skScene.backgroundColor = UIColor.clear
        
        let base = SKSpriteNode()
        base.size = CGSize(width: skScene.frame.width - 10, height: skScene.frame.height - 10)
        base.color = UIColor.white
        base.position = CGPoint(x: skScene.frame.size.width / 2, y: skScene.frame.size.height / 2)
        
        let crec = SKShapeNode()
        crec.fillColor = UIColor.lightGray 
        if countDifference == 0{
            crec.fillColor = UIColor.darkGray 
        }
        crec.strokeColor = particleDictionary?["color"] as! UIColor
        crec.lineWidth = 10
        crec.path = UIBezierPath(roundedRect: CGRect(x: 5, y: 5, width: skScene.frame.size.width - 10, height: skScene.frame.size.height - 10), cornerRadius: 100).cgPath
        
        let overlay = SKCropNode()
        overlay.maskNode = base
        crec.addChild(overlay)
        skScene.addChild(crec)
        
        let fontURL = Bundle.main.url(forResource: "OverpassMono-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        let font = UIFont(name: "OverpassMono-Bold", size: 30)!
        
        let qLabel = generateShape.createLabel(string: qString, 
                                                      size: 36, 
                                                      color: particleDictionary?["color"] as! UIColor,
                                                      position: CGPoint(x: (base.frame.size.width / 2), y: base.frame.size.height / 2))
        qLabel.fontName = font.fontName
        skScene.addChild(qLabel)
        
        return skScene
    }
}
