import SceneKit
import SpriteKit

public class coulombView {
    let generateShape = shapeCreation() 
    var electricCharge1: Int = 0
    var electricCharge2: Int = 0
    var elementName: String = "carbon"
    var elementElectronCount1: Int = 0
    var elementElectronCount2: Int = 0
    var countDifference1: Int = 0
    var countDifference2: Int = 0
    public var atomPosition1: SCNVector3 = SCNVector3Make(-0.25, 0, 0)
    public var atomPosition2: SCNVector3 = SCNVector3Make(0.25, 0, 0)
    var atomDistance: Float = 0
    var nodeDistance: Float = 0
    var isRepel: Bool = false
    var isAttract: Bool = false
    var isNeutral: Bool = false
    var duration: TimeInterval = 1
    
    public init() {
    }
    
    public enum Category: Int32 {
        case atom1 = 1
        case atom2 = 2
        case arrow1 = 4
        case arrow2 = 8
    }
    
    private func electricCharge(num: Int) -> Int{
        if num == 1 {
            return electricCharge1
        } else {
            return electricCharge2
        }
    }
    
    private func elementElectronCount(num: Int) -> Int{
        if num == 1 {
            return elementElectronCount1
        } else {
            return elementElectronCount2
        }
    }
    
    private func countDifference(num: Int) -> Int{
        if num == 1 {
            return countDifference1
        } else {
            return countDifference2
        }
    }
    private func atomPosition(num: Int) -> SCNVector3{
        if num == 1 {
            return atomPosition1
        } else {
            return atomPosition2
        }
    }
    
    private func direction() {
        if (electricCharge1 < 0 && electricCharge2 < 0) || (electricCharge1 > 0 && electricCharge2 > 0) {
            isRepel = true 
        } else if (electricCharge1 < 0 && electricCharge2 > 0) || (electricCharge1 < 0 && electricCharge2 > 0) {
            isAttract = true 
        } else if electricCharge1 == 0 || electricCharge2 == 2 {
            isNeutral = true 
        } 
    }
    
    private func getDuration() {
        let dur = pow(getDistance()/0.5,2) / Float(abs(electricCharge1) * abs(electricCharge2))
        
        if dur > 0.1{ 
            duration = TimeInterval(dur)
        } else {
            duration = TimeInterval(0.1)
        }
        
    }
    
    public func getDistance() -> Float {
        let distance = SCNVector3(
            atomPosition2.x - atomPosition1.x,
            atomPosition2.y - atomPosition1.y,
            atomPosition2.z - atomPosition1.z
        )
        let length: Float = sqrtf(distance.x * distance.x + distance.y * distance.y + distance.z * distance.z)
        return length
    }
    
    public func getMidpoint() -> SCNVector3 {
        let midpoint = SCNVector3(
            (atomPosition2.x + atomPosition1.x) / 2,
            (atomPosition2.y - atomPosition1.y) / 2,
            (atomPosition2.z - atomPosition1.z) / 2
        )
        return midpoint
    }
    
    public func getAngle() -> Float{
        let distance = SCNVector3(
            atomPosition2.x - atomPosition1.x,
            atomPosition2.y - atomPosition1.y,
            atomPosition2.z - atomPosition1.z
        )
        let angle: Float = atan2f(distance.z, distance.x)
        
        return angle
    }
    
    public func createCamera() -> SCNNode{
        var cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0.0, y: 0.25, z: 1.5)
        
        return cameraNode
    }
    
    public func createMainNode(charge1: Int, charge2: Int)  -> SCNNode {
        electricCharge1 = charge1
        electricCharge2 = charge2
        
        let elementDictionary = staticDictionary.getElement(name: "carbon")
        elementElectronCount1 = elementDictionary?["electron"] as! Int + (charge1 * -1)
        elementElectronCount2 = elementDictionary?["electron"] as! Int + (charge2 * -1)
        
        direction()
        
        let mainNode = SCNNode()
        
        mainNode.name = "mainNode"
        generateShape.createLighting(node: mainNode)
        generateShape.createInvisiblePlane(node: mainNode)
        
        createAtom(node: mainNode, num: 1)
        createAtom(node: mainNode, num: 2)
        
        return mainNode
    }
    
    public func createAtom(node: SCNNode, num: Int) {
        let atomNode = SCNNode()
        
        createElectrons(node: atomNode, num: num)
        createProtons(node: atomNode)
        createNeutrons(node: atomNode)
        collectTexts(node: atomNode, num: num)
        
        atomNode.name = "charge" + String(num)
        atomNode.position = atomPosition(num: num)
        atomNode.scale = SCNVector3Make(0.25, 0.25, 0.25)
        if num == 2{
            node.categoryBitMask = Int(Category.atom1.rawValue)
        } else {
            node.categoryBitMask = Int(Category.atom2.rawValue)
        }
        atomNode.enumerateHierarchy{ (node, stop) in
            if num == 2{
                node.categoryBitMask = Int(Category.atom1.rawValue)
            } else {
                node.categoryBitMask = Int(Category.atom2.rawValue)
            }
        }
        node.addChildNode(atomNode)
    }
    
    public func q1Node(node: SCNNode){
        getDuration()
        
        let arrowSeriesNode = SCNNode()
        arrowSeriesNode.position = atomPosition1
        arrowSeriesNode.position.y = 0.0875
        let rDistance = (ceil(getDistance() * 100) / 100) + 0.25
        let y = Int(rDistance / 0.05)
        
        if isNeutral != true {
            for i in 1 ... y {
                let arrowShapeNode = generateShape.createArrow(isRepel: isRepel).flattenedClone()
                arrowSeriesNode.addChildNode(arrowShapeNode)
                let x = 0.05 * (Float(i) - 1)
                arrowShapeNode.position = SCNVector3Make(0.05 + x, 0, 0)
                if i == 1 {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                    arrowShapeNode.runAction(generateShape.fadeOut(duration: duration, isRepel: isRepel)) 
                } else if i == (Int(y) - 5) {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                    arrowShapeNode.runAction(generateShape.secondFadeIn(duration: duration, isRepel: isRepel))
                } else if i == y {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                    arrowShapeNode.runAction(generateShape.fadeIn(duration: duration, isRepel: isRepel))
                } else if i > (Int(y) - 5) {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                    arrowShapeNode.runAction(generateShape.fade(duration: duration))
                } else {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                }
            }
        }
        
        arrowSeriesNode.eulerAngles = SCNVector3Make(0, -getAngle(), 0)
        
        let q1Node = SCNNode()
        q1Node.opacity = 1.0
        q1Node.name = "q1Arrow"
        addInfoCard1(node: q1Node, num: 1)
        q1Node.addChildNode(arrowSeriesNode)
        q1Node.enumerateHierarchy{ (node, stop) in
            node.categoryBitMask = Int(Category.arrow1.rawValue)
        }
        node.addChildNode(q1Node)
    }
    
    public func q2Node(node: SCNNode){
        getDuration()
        
        let arrowSeriesNode = SCNNode()
        arrowSeriesNode.position = atomPosition2
        arrowSeriesNode.position.y = 0.0875
        let rDistance = (ceil(getDistance() * 100) / 100) + 0.25
        let y = Int(rDistance / 0.05)
        
        if isNeutral != true {
            for i in 1 ... y {
                let arrowShapeNode = generateShape.createArrow(isRepel: isRepel).flattenedClone()
                arrowSeriesNode.addChildNode(arrowShapeNode)
                let x = 0.05 * (Float(i) - 1)
                arrowShapeNode.position = SCNVector3Make(0.05 + x, 0, 0)
                if i == 1 {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                    arrowShapeNode.runAction(generateShape.fadeOut(duration: duration, isRepel: isRepel))
                } else if i == (Int(y) - 5) {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                    arrowShapeNode.runAction(generateShape.secondFadeIn(duration: duration, isRepel: isRepel))
                } else if i == y {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                    arrowShapeNode.runAction(generateShape.fadeIn(duration: duration, isRepel: isRepel))
                } else if i > (Int(y) - 5) {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                    arrowShapeNode.runAction(generateShape.fade(duration: duration))
                } else {
                    arrowShapeNode.runAction(generateShape.animateArrow(duration: duration, distance: 0.05 + rDistance, isRepel: isRepel))
                }
            }
        }
        arrowSeriesNode.eulerAngles = SCNVector3Make(0, -getAngle() + .pi, 0)
        
        let q2Node = SCNNode()
        addInfoCard2(node: q2Node, num: 2)
        q2Node.opacity = 1.0
        q2Node.name = "q2Arrow"
        q2Node.addChildNode(arrowSeriesNode)
        q2Node.categoryBitMask = Int(Category.arrow2.rawValue)
        q2Node.enumerateHierarchy{ (node, stop) in
            node.categoryBitMask = Int(Category.arrow2.rawValue)
        }
        node.addChildNode(q2Node)
    }
    
    public func collectTexts(node: SCNNode, num: Int) {
        let collectionNode = SCNNode()
        addText(node: collectionNode, num: num)
        addTitleCard(node: collectionNode, num: num)
        addInfoCardQ(node: collectionNode, num: num)
        
        collectionNode.scale = SCNVector3Make(2.0, 2.0, 2.0)
        collectionNode.eulerAngles = SCNVector3Make(-.pi/2, 0, 0)
        collectionNode.position = SCNVector3Make(0, 0.06, 1.375)
        
        node.addChildNode(collectionNode)
    }
    
    
    public func createElectrons(node: SCNNode, num: Int) {
        var electronsNode = SCNNode()
        electronsNode.name = "electronGroup"
        electronsNode.position = SCNVector3Make(0, 0.35, 0)
        
        let firstOrbitElectrons = SCNNode()
        let secondOrbitElectrons = SCNNode()
        let thirdOrbitElectrons = SCNNode()
        
        
        let firstOrbit = generateShape.createOrbit(radius: 0.25)
        firstOrbit.eulerAngles = SCNVector3Make(0, 0, .pi/3)
        let secondOrbit = generateShape.createOrbit(radius: 0.30)
        secondOrbit.eulerAngles = SCNVector3Make(.pi/3, 0, 0)
        let thirdOrbit = generateShape.createOrbit(radius: 0.35)
        thirdOrbit.eulerAngles = SCNVector3Make(.pi/3, .pi/3, 0)
        electronsNode.addChildNode(firstOrbit)
        
        
        if elementElectronCount(num: num) > 0 {
            for i in 1 ... elementElectronCount(num: num) {
                let electronShapeNode = generateShape.createSphere(particleName: "electron")
                
                if i < 3 {
                    let n = i
                    var x = elementElectronCount(num: num)
                    if elementElectronCount(num: num) > 2 { 
                        x = 2
                    }
                    let rotateUnit = ((2 * Float.pi)/Float(x)) * Float(n)
                    electronShapeNode.pivot = SCNMatrix4MakeTranslation(0.25, 0.0, 0.0)
                    electronShapeNode.eulerAngles = SCNVector3Make(0.0, rotateUnit, 0.0)
                    firstOrbitElectrons.addChildNode(electronShapeNode)
                } else if i < 11 {
                    let n = i - 2
                    var x = elementElectronCount(num: num) - 2
                    if elementElectronCount(num: num) > 10 { 
                        x = 8
                    }
                    let rotateUnit = ((2 * Float.pi)/Float(x)) * Float(n)
                    electronShapeNode.pivot = SCNMatrix4MakeTranslation(0.30, 0.0, 0.0)
                    electronShapeNode.eulerAngles = SCNVector3Make(0.0, rotateUnit, 0.0)
                    secondOrbitElectrons.addChildNode(electronShapeNode)
                } else if i < 19 {
                    let n = i - 10
                    var x = elementElectronCount(num: num) - 10
                    if elementElectronCount(num: num) > 18{ 
                        x = 18
                    }
                    let rotateUnit = ((2 * Float.pi)/Float(x)) * Float(n)
                    electronShapeNode.pivot = SCNMatrix4MakeTranslation(0.35, 0.0, 0.0)
                    electronShapeNode.eulerAngles = SCNVector3Make(0.0, rotateUnit, 0.0)
                    thirdOrbitElectrons.addChildNode(electronShapeNode)
                }
                
            }
        }
        
        firstOrbit.addChildNode(firstOrbitElectrons)
        secondOrbit.addChildNode(secondOrbitElectrons)
        thirdOrbit.addChildNode(thirdOrbitElectrons)
        
        if elementElectronCount(num: num) > 2{
            electronsNode.addChildNode(secondOrbit)
        }
        if elementElectronCount(num: num) > 10 {
            electronsNode.addChildNode(thirdOrbit)
        }
        
        firstOrbitElectrons.runAction(generateShape.orbitAnimation(duration: 8))
        secondOrbitElectrons.runAction(generateShape.orbitAnimation(duration: 10))
        thirdOrbitElectrons.runAction(generateShape.orbitAnimation(duration: 12))
        electronsNode.runAction(generateShape.orbitAnimation(duration: 18))
        
        node.addChildNode(electronsNode)
    }
    
    public func createProtons(node: SCNNode) {
        let elementDictionary = staticDictionary.getElement(name: elementName)
        
        let protonsNode = SCNNode()
        protonsNode.position = SCNVector3Make(0, 0.35, 0)
        protonsNode.name = "protons"
        let protonCount = elementDictionary?["proton"] as! Int
        
        let protonsPositions = elementDictionary?["protonPositions"] as! Array<String>
        var isSetA = elementDictionary?["isDefault"] as! Bool
        
        for i in 0 ... (protonCount - 1){
            let protonShapeNode = generateShape.createSphere(particleName: "proton")
            let position = staticDictionary.getCoordinates(isDefault: isSetA, code: protonsPositions[i]) 
            protonShapeNode.position = position ?? SCNVector3Zero
            protonsNode.addChildNode(protonShapeNode)
        }
        
        node.addChildNode(protonsNode)
    }
    
    public func createNeutrons(node: SCNNode) {
        let elementDictionary = staticDictionary.getElement(name: elementName)
        
        let neutronsNode = SCNNode() 
        neutronsNode.position = SCNVector3Make(0, 0.35, 0)
        neutronsNode.name = "neutrons"
        let neutronCount = elementDictionary?["neutron"] as! Int
        
        if neutronCount != 0 {
            let neutronsPositions = elementDictionary?["neutronPositions"] as! Array<String>
            var isSetA = elementDictionary?["isDefault"] as! Bool
            
            for i in 0 ... (neutronCount - 1){
                let neutronShapeNode = generateShape.createSphere(particleName: "neutron")
                let position = staticDictionary.getCoordinates(isDefault: isSetA, code: neutronsPositions[i]) 
                neutronShapeNode.position = position ?? SCNVector3Zero
                neutronsNode.addChildNode(neutronShapeNode)
            }
        }
        node.addChildNode(neutronsNode)
    }
    
    public func addText(node: SCNNode, num: Int) {
        let elementDictionary = staticDictionary.getElement(name: elementName)
        let symbol = elementDictionary?["symbol"] as! String
        
        let symbolText = generateShape.createTextShape(string: symbol, size: 1)
        
        let symbolTextNode = SCNNode(geometry: symbolText)
        let max, min: SCNVector3
        max = symbolTextNode.boundingBox.max
        min = symbolTextNode.boundingBox.min
        symbolTextNode.pivot = SCNMatrix4MakeTranslation(
            min.x + (max.x - min.x)/2,
            min.y + (max.y - min.y)/2,
            min.z + (max.z - min.z)/2
        )
        symbolTextNode.scale = SCNVector3(0.1, 0.1, 0.1)
        symbolTextNode.position = SCNVector3(0, 0.05, 0.0)
        
        var chargeString = String(electricCharge(num: num))
        
        if electricCharge(num: num) > 1 {
            chargeString = "+" + chargeString 
        } else if electricCharge(num: num) == -1 {
            chargeString = "-" 
        } else if electricCharge(num: num) == 1 {
            chargeString = "+" 
        } 
        
        let chargeText = generateShape.createTextShape(string: chargeString, size: 0.5)
        let chargeTextNode = SCNNode(geometry: chargeText)
        let cmax, cmin: SCNVector3
        cmax = chargeTextNode.boundingBox.max
        cmin = chargeTextNode.boundingBox.min
        chargeTextNode.pivot = SCNMatrix4MakeTranslation(
            cmin.x + (cmax.x - cmin.x)/2,
            cmin.y + (cmax.y - cmin.y)/2,
            cmin.z + (cmax.z - cmin.z)/2
        )
        chargeTextNode.position = SCNVector3Make(((max.x + cmax.x) / 2 * 0.1), symbolTextNode.position.y + 0.025, ((max.z - min.z) * 0.1 / 2) + symbolTextNode.position.z) 
        chargeTextNode.scale = SCNVector3(0.1, 0.1, 0.1)
        
        var particleName: String = ""
        
        if electricCharge(num: num) == 0 {
            particleName = "neutron"
        } else if electricCharge(num: num) > 0 {
            particleName = "proton"
        } else {
            particleName = "electron"
        }
        
        symbolText.firstMaterial? = generateShape.createTextMaterial(particleName: particleName)
        chargeText.firstMaterial? = generateShape.createTextMaterial(particleName: particleName)
        
        let textNode = SCNNode()
        textNode.addChildNode(symbolTextNode)
        textNode.position = SCNVector3(0, 0.45, 0)
        if electricCharge(num: num) != 0 {
            textNode.addChildNode(chargeTextNode)
            textNode.position = SCNVector3(-(symbolTextNode.position.x + chargeTextNode.position.x) / 3, 0.45, 0)
        }
        node.addChildNode(textNode)
    }
    
    public func addTitleCard(node: SCNNode, num: Int){
        let plane = SCNPlane(width: 0.28, height: 0.06)
        plane.firstMaterial? = generateShape.createCardMaterial()
        plane.firstMaterial?.diffuse.contents = titleContents(num: num)
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles = SCNVector3Make(0.0, 0.0, 0.0)
        planeNode.position = SCNVector3Make(0, 0.425, 0.0)
        planeNode.castsShadow = false
        node.addChildNode(planeNode)
    }
    
    public func titleContents(num: Int) -> SKScene{
        let elementDictionary = staticDictionary.getElement(name: elementName)
        let elementCounts = [elementDictionary?["proton"], elementDictionary?["neutron"], elementElectronCount]
        
        var particleName = ""
        
        if electricCharge(num: num)  == 0 {
            particleName = "neutron"
        } else if electricCharge(num: num)  > 0 {
            particleName = "proton"
        } else {
            particleName = "electron"
        }
        let particleDictionary = staticDictionary.getParticle(name: particleName)
        
        let skScene = SKScene(size:CGSize(width: 700, height: 150))
        skScene.backgroundColor = UIColor.clear
        
        let shape = SKShapeNode(rect: CGRect(x: 0, y: 0, width: skScene.frame.size.width, height: skScene.frame.size.height))
        
        shape.fillColor = particleDictionary?["color"] as! UIColor
        shape.strokeColor = UIColor.clear
        shape.path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: skScene.frame.size.width, height: skScene.frame.size.height), cornerRadius: 25).cgPath
        skScene.addChild(shape)
        
        let label = generateShape.createLabel(string: elementName, 
                                              size: 108, 
                                              color: UIColor.white, 
                                              position: CGPoint(x: shape.frame.size.width / 2, y: shape.frame.size.height / 2))
        skScene.addChild(label)
        
        return skScene
    }
    
    public func addInfoCardQ(node: SCNNode, num: Int){
        let qCard = SCNNode()
        
        let plane = SCNPlane(width: 0.20, height: 0.04)
        plane.firstMaterial? = generateShape.createCardMaterial()
        plane.firstMaterial?.diffuse.contents = chargeContents(num: num)
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles = SCNVector3Make(0.0, 0.0, 0.0)
        planeNode.position = SCNVector3Make(0.04, 0.35, 0.0)
        planeNode.castsShadow = false
        qCard.addChildNode(planeNode)
        
        let chargeNode = SCNNode()
        if countDifference(num: num) > 0 {
            chargeNode.addChildNode(generateShape.createPositiveChargeMini())
        } else if countDifference(num: num) < 0 {
            chargeNode.addChildNode(generateShape.createNegativeChargeMini())
        } else {
            chargeNode.addChildNode(generateShape.createNeutralChargeMini())
        }
        
        chargeNode.position = SCNVector3Make(-0.10, 0.35, 0.0)
        qCard.addChildNode(chargeNode)
        
        node.addChildNode(qCard)
    }
    
    public func chargeContents(num: Int) -> SKScene{
        var particleName = ""
        if electricCharge(num: num) == 0 {
            particleName = "neutron"
        } else if electricCharge(num: num) > 0 {
            particleName = "proton"
        } else {
            particleName = "electron"
        }
        let particleDictionary = staticDictionary.getParticle(name: particleName)
        
        let elementDictionary = staticDictionary.getElement(name: elementName)
        let protonCount = elementDictionary?["proton"] as! Int
        if num == 1 {
            countDifference1 = protonCount - elementElectronCount(num: num)
        } else {
            countDifference2 = protonCount - elementElectronCount(num: num)
        }
        
        let q = Double(countDifference(num: num)) * 0.00000000000000000016021766341
        
        let formatter = NumberFormatter()
        formatter.numberStyle = .scientific
        formatter.positiveFormat = "+0.#E{+0}"
        formatter.negativeFormat = "-0.###E{-0}"
        formatter.exponentSymbol = " × 10^{"
        formatter.usesSignificantDigits = true
        formatter.maximumSignificantDigits = 2
        var qString = formatter.string(for: q)! + "}"
        qString = "q = " + qString.superscripted() + " C"
        if countDifference(num: num) == 0 {
            qString = "NEUTRAL CHARGE"
        }
        let skScene = SKScene(size:CGSize(width: 510, height: 110))
        skScene.backgroundColor = UIColor.clear
        
        let base = SKSpriteNode()
        base.size = CGSize(width: skScene.frame.width - 10, height: skScene.frame.height - 10)
        base.color = UIColor.white
        base.position = CGPoint(x: skScene.frame.size.width / 2, y: skScene.frame.size.height / 2)
        
        let crec = SKShapeNode()
        crec.fillColor = UIColor.lightGray 
        if countDifference(num: num) == 0{
            crec.fillColor = UIColor.darkGray 
        }
        crec.strokeColor = particleDictionary?["color"] as! UIColor
        crec.lineWidth = 10
        crec.path = UIBezierPath(roundedRect: CGRect(x: 5, y: 5, width: skScene.frame.size.width - 10, height: skScene.frame.size.height - 10), cornerRadius: 100).cgPath
        
        let overlay = SKCropNode()
        overlay.maskNode = base
        crec.addChild(overlay)
        skScene.addChild(crec)
        
        let fontURL = Bundle.main.url(forResource: "OverpassMono-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        let font = UIFont(name: "OverpassMono-Bold", size: 30)!
        
        let qLabel = generateShape.createLabel(string: qString, 
                                               size: 36, 
                                               color: particleDictionary?["color"] as! UIColor,
                                               position: CGPoint(x: (base.frame.size.width / 2), y: base.frame.size.height / 2))
        qLabel.fontName = font.fontName
        skScene.addChild(qLabel)
        
        return skScene
    }
    public func addInfoCard1(node: SCNNode, num: Int){
        let iCard = SCNNode()
        
        let plane = SCNPlane(width: 0.24, height: 0.09)
        plane.firstMaterial? = generateShape.createCardMaterial()
        plane.firstMaterial?.diffuse.contents = infoContents1(num: 1)
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles = SCNVector3Make(-.pi/2, 0.0, 0.0)
        planeNode.castsShadow = false
        iCard.addChildNode(planeNode)
        iCard.scale = SCNVector3Make(0.6, 0.6, 0.6)
        planeNode.position = SCNVector3Make(atomPosition1.x + 0.05, 0.0875, atomPosition1.z + 0.1)
        
        node.addChildNode(iCard)
    }
    
    public func infoContents1(num: Int) -> SKScene{
        var mdistance = Double(getDistance()) * 0.00000001
        let q1 = Double(countDifference(num: 1)) * 0.00000000000000000016021766341
        let q2 = Double(countDifference(num: 2)) * 0.00000000000000000016021766341
        let k = Double(8987551792.3)
        let f = abs(k * q1 * q2 / pow(mdistance, 2))
        
        
        let formatter = NumberFormatter()
        formatter.numberStyle = .scientific
        formatter.positiveFormat = "+0.#E{+0}"
        formatter.negativeFormat = "-0.###E{-0}"
        formatter.exponentSymbol = " × 10^{"
        formatter.usesSignificantDigits = true
        formatter.maximumSignificantDigits = 2
        
        var iString1 = formatter.string(for: mdistance)! + "}"
        iString1 = "When " + iString1.superscripted() + " m apart,"
        
        var iString2 = formatter.string(for: f)! + "}"
        iString2 = "q1 exerts " + iString2.superscripted() + " N"
        
        
        var pString = "pulling"
        if isRepel == true {
            pString = "pushing"
        }
        var iString3 = formatter.string(for: f)! + "}"
        iString3 = "of force " + pString + " q2"
        
        
        if isNeutral == true {
            iString1 = ""
            iString2 = "No force exerted."
            iString3 = ""
        }
        
        let skScene = SKScene(size:CGSize(width: 610, height: 235))
        skScene.backgroundColor = UIColor.clear
        
        let base = SKSpriteNode()
        base.size = CGSize(width: skScene.frame.width - 10, height: skScene.frame.height - 10)
        base.color = UIColor.white
        base.position = CGPoint(x: skScene.frame.size.width / 2, y: skScene.frame.size.height / 2)
        
        let crec = SKShapeNode()
        crec.fillColor = UIColor.lightGray 
        if countDifference(num: num) == 0{
            crec.fillColor = UIColor.darkGray 
        }
        crec.strokeColor = UIColor.black
        crec.lineWidth = 10
        crec.path = UIBezierPath(roundedRect: CGRect(x: 5, y: 5, width: skScene.frame.size.width - 10, height: skScene.frame.size.height - 10), cornerRadius: 50).cgPath
        
        let overlay = SKCropNode()
        overlay.maskNode = base
        crec.addChild(overlay)
        skScene.addChild(crec)
        
        let fontURL = Bundle.main.url(forResource: "OverpassMono-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        let font = UIFont(name: "OverpassMono-Bold", size: 30)!
        
        let iLabel1 = generateShape.createLabel(string: iString1, 
                                               size: 36, 
                                               color: UIColor.black,
                                               position: CGPoint(x: (base.frame.size.width / 2), y: (base.frame.size.height / 2) + 50))
        iLabel1.fontName = font.fontName
        
        let iLabel2 = generateShape.createLabel(string: iString2, 
                                                size: 36, 
                                                color: UIColor.black,
                                                position: CGPoint(x: (base.frame.size.width / 2), y: base.frame.size.height / 2))
        iLabel2.fontName = font.fontName
        
        let iLabel3 = generateShape.createLabel(string: iString3, 
                                                size: 36, 
                                                color: UIColor.black,
                                                position: CGPoint(x: (base.frame.size.width / 2), y: (base.frame.size.height / 2) - 50))
        iLabel3.fontName = font.fontName
        
        skScene.addChild(iLabel1)
        skScene.addChild(iLabel2)
        skScene.addChild(iLabel3)
        
        return skScene
    }
    public func addInfoCard2(node: SCNNode, num: Int){
        let iCard = SCNNode()
        
        let plane = SCNPlane(width: 0.24, height: 0.09)
        plane.firstMaterial? = generateShape.createCardMaterial()
        plane.firstMaterial?.diffuse.contents = infoContents2(num: 2)
        let planeNode = SCNNode(geometry: plane)
        planeNode.eulerAngles = SCNVector3Make(-.pi/2, 0.0, 0.0)
        planeNode.castsShadow = false
        iCard.addChildNode(planeNode)
        iCard.scale = SCNVector3Make(0.6, 0.6, 0.6)
        planeNode.position = SCNVector3Make(atomPosition2.x - 0.05, 0.0875, atomPosition2.z + 0.1)
        
        node.addChildNode(iCard)
    }
    
    public func infoContents2(num: Int) -> SKScene{
        var mdistance = Double(getDistance()) * 0.00000001
        let q1 = Double(countDifference(num: 1)) * 0.00000000000000000016021766341
        let q2 = Double(countDifference(num: 2)) * 0.00000000000000000016021766341
        let k = Double(8987551792.3)
        let f = abs(k * q1 * q2 / pow(mdistance, 2))
        
        
        let formatter = NumberFormatter()
        formatter.numberStyle = .scientific
        formatter.positiveFormat = "+0.#E{+0}"
        formatter.negativeFormat = "-0.###E{-0}"
        formatter.exponentSymbol = " × 10^{"
        formatter.usesSignificantDigits = true
        formatter.maximumSignificantDigits = 2
        
        var iString1 = formatter.string(for: mdistance)! + "}"
        iString1 = "When " + iString1.superscripted() + " m apart,"
        
        var iString2 = formatter.string(for: f)! + "}"
        iString2 = "q2 exerts " + iString2.superscripted() + " N"
        
        
        var pString = "pulling"
        if isRepel == true {
            pString = "pushing"
        }
        var iString3 = formatter.string(for: f)! + "}"
        iString3 = "of force " + pString + " q1"
        
        
        if isNeutral == true {
            iString1 = ""
            iString2 = "No force exerted."
            iString3 = ""
        }
        
        let skScene = SKScene(size:CGSize(width: 610, height: 235))
        skScene.backgroundColor = UIColor.clear
        
        let base = SKSpriteNode()
        base.size = CGSize(width: skScene.frame.width - 10, height: skScene.frame.height - 10)
        base.color = UIColor.white
        base.position = CGPoint(x: skScene.frame.size.width / 2, y: skScene.frame.size.height / 2)
        
        let crec = SKShapeNode()
        crec.fillColor = UIColor.lightGray 
        if countDifference(num: num) == 0{
            crec.fillColor = UIColor.darkGray 
        }
        crec.strokeColor = UIColor.black
        crec.lineWidth = 10
        crec.path = UIBezierPath(roundedRect: CGRect(x: 5, y: 5, width: skScene.frame.size.width - 10, height: skScene.frame.size.height - 10), cornerRadius: 50).cgPath
        
        let overlay = SKCropNode()
        overlay.maskNode = base
        crec.addChild(overlay)
        skScene.addChild(crec)
        
        let fontURL = Bundle.main.url(forResource: "OverpassMono-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        let font = UIFont(name: "OverpassMono-Bold", size: 30)!
        
        let iLabel1 = generateShape.createLabel(string: iString1, 
                                                size: 36, 
                                                color: UIColor.black,
                                                position: CGPoint(x: (base.frame.size.width / 2), y: (base.frame.size.height / 2) + 50))
        iLabel1.fontName = font.fontName
        
        let iLabel2 = generateShape.createLabel(string: iString2, 
                                                size: 36, 
                                                color: UIColor.black,
                                                position: CGPoint(x: (base.frame.size.width / 2), y: base.frame.size.height / 2))
        iLabel2.fontName = font.fontName
        
        let iLabel3 = generateShape.createLabel(string: iString3, 
                                                size: 36, 
                                                color: UIColor.black,
                                                position: CGPoint(x: (base.frame.size.width / 2), y: (base.frame.size.height / 2) - 50))
        iLabel3.fontName = font.fontName
        
        skScene.addChild(iLabel1)
        skScene.addChild(iLabel2)
        skScene.addChild(iLabel3)
        
        return skScene
    }
}
