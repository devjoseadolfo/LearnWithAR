import UIKit
import SceneKit
import SpriteKit

public enum Category: Int {
    case source = 2
    case test = 4
    case other = 8
    case source2 = 16
}

public class fieldView1{
    
    public init (){
    }
    
    public func createCamera() -> SCNNode{
        var cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0.0, y: 2, z: 2)
        cameraNode.eulerAngles = SCNVector3Make(-.pi/4, 0, 0)
        
        return cameraNode
    }
    
    public func createMainFieldNode() -> SCNNode{
        let mainFieldNode = SCNNode()
        
        mainFieldNode.addChildNode(createFieldArrow(length: 0.02, color: UIColor.blue, isRepel: true))
        
        return mainFieldNode
    }
    
    public func createFieldArrow(length: Float, color: UIColor, isRepel: Bool) -> SCNNode {
        let arrowNode = SCNNode()
        let cone = SCNCone(topRadius: 0.0, bottomRadius: 0.008, height: 0.02)
        let coneNode = SCNNode(geometry: cone)
        coneNode.localTranslate(by: SCNVector3Make((length / 2) - 0.01 - 0.001, 0, 0))
        coneNode.eulerAngles.z = -.pi/2
        coneNode
        let cylLength = length - 0.02
        let cylinder = SCNCylinder(radius: 0.004, height: CGFloat(cylLength))
        let cylinderNode = SCNNode(geometry: cylinder)
        cylinderNode.localTranslate(by: SCNVector3Make(-(length / 2) + (cylLength / 2) + 0.001, 0, 0))
        cylinderNode.eulerAngles.z = -.pi/2
        
        arrowNode.addChildNode(coneNode)
        if length >= 0.02 {
            arrowNode.addChildNode(cylinderNode)
        }
        
        let flatArrowNode = arrowNode.flattenedClone()
        flatArrowNode.geometry?.materials = [createFieldArrowMaterial(color: color)]
        flatArrowNode.name = "arrow"
        flatArrowNode.castsShadow = false
        return flatArrowNode
    }
    
    public func createFieldArrowMaterial(color: UIColor) -> SCNMaterial {
        let material = SCNMaterial()
        material.lightingModel = .physicallyBased
        material.isDoubleSided = true
        material.diffuse.contents = color
        material.roughness.contents = 0.3
        material.metalness.contents = 0.9
        material.selfIllumination.contents = 0.7
        return material
    }
    
    public func createPositiveCharge(scale: Float, emit: Float, isTest: Bool) -> SCNNode{
        let miniPositiveCharge = SCNNode()
        var color = UIColor.red
        if isTest == true {
            color = UIColor.green
        }
        
        let torus = SCNTorus(ringRadius: 0.03, pipeRadius: 0.006)
        torus.firstMaterial? = createMetallicMaterial(diffuse: color)
        let torusNode = SCNNode(geometry: torus)
        torusNode.eulerAngles = SCNVector3Make(0, 0, .pi/2)
        
        let glowTorus = SCNTorus(ringRadius: 0.03, pipeRadius: 0.006)
        glowTorus.firstMaterial? = createGlowMaterial(diffuse: color, emit: emit)
        let glowTorusNode = SCNNode(geometry: glowTorus)
        glowTorusNode.eulerAngles = SCNVector3Make(0, 0, .pi/2)
        miniPositiveCharge.addChildNode(glowTorusNode)
        
        let cylinder1 = SCNCapsule(capRadius: 0.0075, height: 0.04)
        let cylinder1Node = SCNNode(geometry: cylinder1)
        let cylinder2 = SCNCapsule(capRadius: 0.0075, height: 0.040)
        let cylinder2Node = SCNNode(geometry: cylinder2)
        cylinder2Node.eulerAngles = SCNVector3Make(.pi/2, 0, 0)
        
        let plusNode = SCNNode()
        plusNode.addChildNode(cylinder1Node)
        plusNode.addChildNode(cylinder2Node)
        let flatPlusNode = plusNode.flattenedClone()
        flatPlusNode.geometry?.materials = [createMetallicMaterial(diffuse: color)]
        
        let glowCylinder1 = SCNCapsule(capRadius: 0.0075, height: 0.04)
        let glowCylinder1Node = SCNNode(geometry: glowCylinder1)
        let glowCylinder2 = SCNCapsule(capRadius: 0.0075, height: 0.04)
        let glowCylinder2Node = SCNNode(geometry: glowCylinder2)
        glowCylinder2Node.eulerAngles = SCNVector3Make(.pi/2, 0, 0)
        
        let glowPlusNode = SCNNode()
        glowPlusNode.addChildNode(glowCylinder1Node)
        glowPlusNode.addChildNode(glowCylinder2Node)
        let glowFlatPlusNode = glowPlusNode.flattenedClone()
        glowFlatPlusNode.geometry?.materials = [createGlowMaterial(diffuse: color, emit: emit)]
        
        miniPositiveCharge.addChildNode(flatPlusNode)
        miniPositiveCharge.addChildNode(glowFlatPlusNode)
        miniPositiveCharge.addChildNode(torusNode)
        
        miniPositiveCharge.eulerAngles = SCNVector3Make(0.0, 0.0, .pi/2)
        miniPositiveCharge.scale = SCNVector3Make(0.5 * scale, 0.5 * scale, 0.5 * scale)
        return miniPositiveCharge
    }
    
    public func createNeutralCharge(scale: Float) -> SCNNode{
        let miniNeutralCharge = SCNNode()
        
        let torus = SCNTorus(ringRadius: 0.03, pipeRadius: 0.006)
        torus.firstMaterial? = createMetallicMaterial(diffuse: UIColor(red: 1.0, green: 0.7, blue: 0.0, alpha: 1.0))
        torus.firstMaterial?.roughness.contents = 0.8
        let torusNode = SCNNode(geometry: torus)
        torusNode.eulerAngles = SCNVector3Make(.pi/2, 0, 0)
        miniNeutralCharge.addChildNode(torusNode)
        
        let fontURL = Bundle.main.url(forResource: "OverpassMono-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        let text = SCNText(string: "N", extrusionDepth: 0.1)
        text.font =  UIFont(name: "OverpassMono-Bold", size: 1.20)
        text.flatness = 0
        text.chamferRadius = 0.1
        
        let textNode = SCNNode(geometry: text)
        let max, min: SCNVector3
        max = textNode.boundingBox.max
        min = textNode.boundingBox.min
        textNode.pivot = SCNMatrix4MakeTranslation(
            min.x + (max.x - min.x)/2,
            min.y + (max.y - min.y)/2,
            min.z + (max.z - min.z)/2
        )
        textNode.scale = SCNVector3(0.04, 0.04, 0.04)
        textNode.geometry?.firstMaterial? = createMetallicMaterial(diffuse: UIColor(red: 1.0, green: 0.7, blue: 0.0, alpha: 1.0))
        textNode.geometry?.firstMaterial?.roughness.contents = 0.5
        
        miniNeutralCharge.addChildNode(textNode)
        miniNeutralCharge.scale = SCNVector3Make(0.5 * scale, 0.5 * scale, 0.5 * scale)
        miniNeutralCharge.eulerAngles = SCNVector3Make(-.pi/2, 0.0, 0.0)
        
        return miniNeutralCharge
    }
    
    public func createNegativeCharge(scale: Float, emit: Float) -> SCNNode{
        let miniNegativeCharge = SCNNode()
        
        let torus = SCNTorus(ringRadius: 0.03, pipeRadius: 0.006)
        torus.firstMaterial? = createMetallicMaterial(diffuse: UIColor.systemBlue)
        let torusNode = SCNNode(geometry: torus)
        torusNode.eulerAngles = SCNVector3Make(.pi/2, 0, 0)
        miniNegativeCharge.addChildNode(torusNode)
        
        let glowTorus = SCNTorus(ringRadius: 0.03, pipeRadius: 0.006)
        glowTorus.firstMaterial? = createGlowMaterial(diffuse: UIColor.systemBlue, emit: emit)
        let glowTorusNode = SCNNode(geometry: glowTorus)
        glowTorusNode.eulerAngles = SCNVector3Make(.pi/2, 0, 0)
        miniNegativeCharge.addChildNode(glowTorusNode)
        
        let cylinder = SCNCapsule(capRadius: 0.0075, height: 0.04)
        cylinder.firstMaterial? = createMetallicMaterial(diffuse: UIColor.systemBlue)
        let cylinderNode = SCNNode(geometry: cylinder)
        cylinderNode.eulerAngles = SCNVector3Make(0, 0, -.pi/2)
        miniNegativeCharge.addChildNode(cylinderNode)
        
        let glowCylinder = SCNCapsule(capRadius: 0.0075, height: 0.04)
        glowCylinder.firstMaterial? = createGlowMaterial(diffuse: UIColor.systemBlue, emit: emit)
        let glowCylinderNode = SCNNode(geometry: glowCylinder)
        glowCylinderNode.eulerAngles = SCNVector3Make(0, 0, -.pi/2)
        miniNegativeCharge.addChildNode(glowCylinderNode)
        
        miniNegativeCharge.scale = SCNVector3Make(0.5 * scale, 0.5 * scale, 0.5 * scale)
        miniNegativeCharge.eulerAngles = SCNVector3Make(-.pi/2, 0.0, 0.0)
        
        return miniNegativeCharge
    }
    
    public func createMetallicMaterial(diffuse: UIColor) -> SCNMaterial {
        let material = SCNMaterial()
        material.diffuse.contents = diffuse
        material.metalness.contents = 0.9
        material.specular.contents = UIColor.white
        material.roughness.contents = 0.3
        material.lightingModel = .physicallyBased
        return material
    }
    public func createGlowMaterial(diffuse: UIColor, emit: Float) -> SCNMaterial {
        let material = SCNMaterial()
        material.diffuse.contents = diffuse
        material.reflective.contents = UIColor.lightGray
        material.reflective.intensity = 1.75 + CGFloat(0.25 * emit)
        material.transparent.contents = UIColor.black.withAlphaComponent(0.1)
        material.transparencyMode = .default
        material.specular.contents = UIColor.white
        material.fresnelExponent = CGFloat(2/emit)
        material.blendMode = .max
        return material
    }
}

