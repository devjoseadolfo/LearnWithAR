
import PlaygroundSupport
import Dispatch
import Foundation
import UIKit

public func goToNextPage() -> String {
    return "\n\n[**Next Page**](@next)"
}

public func goToPrevPage() -> String {
    return "\n\n[**Previous Page**](@previous)"
}
