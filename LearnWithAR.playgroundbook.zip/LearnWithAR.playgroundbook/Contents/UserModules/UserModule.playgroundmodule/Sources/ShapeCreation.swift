// Code inside modules can be shared between pages and other source files.
import SceneKit
import SpriteKit

public class shapeCreation {
    public init() {
    }
    
    public func createSphere(particleName: String) -> SCNNode{
        let particle = staticDictionary.getParticle(name: particleName)
        let size = particle?["size"]
        let color = particle?["color"]
        let sphere = SCNSphere(radius: (size as! CGFloat) * 1.0)
        sphere.firstMaterial = createMetallicMaterial(diffuse: color as! UIColor)
        let sphereNode = SCNNode(geometry: sphere)
        sphereNode.name = particleName
        
        let particleSphere = SCNNode()
        particleSphere.addChildNode(sphereNode)
        
        if particleName != "neutron" {
            let glow = SCNSphere(radius: (size as! CGFloat) * 1.0)
            glow.firstMaterial = createGlowMaterial(diffuse: color as! UIColor)
            let glowNode = SCNNode(geometry: glow)
            glowNode.name = particleName
            particleSphere.addChildNode(glowNode)
        } else {
            sphere.firstMaterial?.roughness.contents = 0.5
        }
        
        return particleSphere
    }
    
    public func createPositiveChargeMini() -> SCNNode{
        let miniPositiveCharge = SCNNode()
        
        let torus = SCNTorus(ringRadius: 0.03, pipeRadius: 0.006)
        torus.firstMaterial? = createMetallicMaterial(diffuse: UIColor.red)
        let torusNode = SCNNode(geometry: torus)
        torusNode.eulerAngles = SCNVector3Make(.pi/2, 0, 0)
        miniPositiveCharge.addChildNode(torusNode)
        
        let glowTorus = SCNTorus(ringRadius: 0.03, pipeRadius: 0.006)
        glowTorus.firstMaterial? = createGlowMaterial(diffuse: UIColor.red)
        let glowTorusNode = SCNNode(geometry: glowTorus)
        glowTorusNode.eulerAngles = SCNVector3Make(.pi/2, 0, 0)
        miniPositiveCharge.addChildNode(glowTorusNode)
        
        let cylinder1 = SCNCapsule(capRadius: 0.0075, height: 0.04)
        let cylinder1Node = SCNNode(geometry: cylinder1)
        let cylinder2 = SCNCapsule(capRadius: 0.0075, height: 0.040)
        let cylinder2Node = SCNNode(geometry: cylinder2)
        cylinder2Node.eulerAngles = SCNVector3Make(0, 0, -.pi/2)
        
        let plusNode = SCNNode()
        plusNode.addChildNode(cylinder1Node)
        plusNode.addChildNode(cylinder2Node)
        let flatPlusNode = plusNode.flattenedClone()
        flatPlusNode.geometry?.materials = [createMetallicMaterial(diffuse: UIColor.red)]
            
        let glowCylinder1 = SCNCapsule(capRadius: 0.0075, height: 0.04)
        let glowCylinder1Node = SCNNode(geometry: glowCylinder1)
        let glowCylinder2 = SCNCapsule(capRadius: 0.0075, height: 0.04)
        let glowCylinder2Node = SCNNode(geometry: glowCylinder2)
        glowCylinder2Node.eulerAngles = SCNVector3Make(0, 0, -.pi/2)
        
        let glowPlusNode = SCNNode()
        glowPlusNode.addChildNode(glowCylinder1Node)
        glowPlusNode.addChildNode(glowCylinder2Node)
        let glowFlatPlusNode = glowPlusNode.flattenedClone()
        glowFlatPlusNode.geometry?.materials = [createGlowMaterial(diffuse: UIColor.red)]
        
        miniPositiveCharge.addChildNode(flatPlusNode)
        miniPositiveCharge.addChildNode(glowFlatPlusNode)
        miniPositiveCharge.runAction(orbitAnimation(duration: 5))
        
        return miniPositiveCharge
    }
    
    public func createNeutralChargeMini() -> SCNNode{
        let miniNeutralCharge = SCNNode()
        
        let torus = SCNTorus(ringRadius: 0.03, pipeRadius: 0.006)
        torus.firstMaterial? = createMetallicMaterial(diffuse: UIColor(red: 1.0, green: 0.7, blue: 0.0, alpha: 1.0))
        torus.firstMaterial?.roughness.contents = 0.8
        let torusNode = SCNNode(geometry: torus)
        torusNode.eulerAngles = SCNVector3Make(.pi/2, 0, 0)
        miniNeutralCharge.addChildNode(torusNode)
        
        let fontURL = Bundle.main.url(forResource: "OverpassMono-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        let text = SCNText(string: "N", extrusionDepth: 0.1)
        text.font =  UIFont(name: "OverpassMono-Bold", size: 1.20)
        text.flatness = 0
        text.chamferRadius = 0.1
        
        let textNode = SCNNode(geometry: text)
        let max, min: SCNVector3
        max = textNode.boundingBox.max
        min = textNode.boundingBox.min
        textNode.pivot = SCNMatrix4MakeTranslation(
            min.x + (max.x - min.x)/2,
            min.y + (max.y - min.y)/2,
            min.z + (max.z - min.z)/2
        )
        textNode.scale = SCNVector3(0.04, 0.04, 0.04)
        miniNeutralCharge.addChildNode(textNode)
        textNode.geometry?.firstMaterial? = createMetallicMaterial(diffuse: UIColor(red: 1.0, green: 0.7, blue: 0.0, alpha: 1.0))
        textNode.geometry?.firstMaterial?.roughness.contents = 0.5
        miniNeutralCharge.runAction(orbitAnimation(duration: 5))
        
        return miniNeutralCharge
    }
    
    public func createNegativeChargeMini() -> SCNNode{
        let miniNegativeCharge = SCNNode()
        
        let torus = SCNTorus(ringRadius: 0.03, pipeRadius: 0.006)
        torus.firstMaterial? = createMetallicMaterial(diffuse: UIColor.systemBlue)
        let torusNode = SCNNode(geometry: torus)
        torusNode.eulerAngles = SCNVector3Make(.pi/2, 0, 0)
        miniNegativeCharge.addChildNode(torusNode)
        
        let cylinder = SCNCapsule(capRadius: 0.0075, height: 0.04)
        cylinder.firstMaterial? = createMetallicMaterial(diffuse: UIColor.systemBlue)
        let cylinderNode = SCNNode(geometry: cylinder)
        cylinderNode.eulerAngles = SCNVector3Make(0, 0, -.pi/2)
        
        let minusNode = SCNNode()
        minusNode.addChildNode(cylinderNode)
        
        miniNegativeCharge.addChildNode(minusNode)
        miniNegativeCharge.runAction(orbitAnimation(duration: 5))
        
        return miniNegativeCharge
    }
    
    public func createOrbit(radius: CGFloat) -> SCNNode{
        let torus = SCNTorus(ringRadius: radius, pipeRadius: 0.002)
        let torusMaterial = torus.firstMaterial
        torusMaterial?.transparency = 0.3
        torusMaterial?.transparencyMode = .singleLayer
        torusMaterial?.diffuse.contents = UIColor.black
        let torusNode = SCNNode(geometry: torus)
        return torusNode
    }
    
    public func createMetallicMaterial(diffuse: UIColor) -> SCNMaterial {
        let material = SCNMaterial()
        material.diffuse.contents = diffuse
        material.metalness.contents = 0.9
        material.specular.contents = UIColor.white
        material.roughness.contents = 0.3
        material.lightingModel = .physicallyBased
        return material
    }
    public func createGlowMaterial(diffuse: UIColor) -> SCNMaterial {
        let material = SCNMaterial()
        material.diffuse.contents = diffuse
        material.reflective.contents = diffuse
        material.reflective.intensity = 5
        material.transparent.contents = UIColor.black.withAlphaComponent(0.2)
        material.transparencyMode = .default
        material.specular.contents = UIColor.white
        material.fresnelExponent = 2
        material.blendMode = .max
        return material
    }
    public func orbitAnimation(duration: Double) -> SCNAction{
        let orbitPath = SCNAction.rotateBy(x: 0.0, y: .pi, z: 0, duration: duration)
        let moveSequence = SCNAction.sequence([orbitPath])
        let moveLoop = SCNAction.repeatForever(moveSequence)
        return moveLoop
    }
    public func createInvisiblePlane(node: SCNNode) {
        let plane = SCNPlane(width: 200, height: 200)
        plane.firstMaterial?.colorBufferWriteMask = .init(rawValue: 0)
        let planeNode = SCNNode(geometry: plane)
        planeNode.rotation = SCNVector4Make(1, 0, 0, -Float.pi / 2)
        planeNode.position = SCNVector3Make(0, -0.001, 0)
        node.addChildNode(planeNode)
    }
    public func createCardMaterial() -> SCNMaterial {
        let material = SCNMaterial()
        material.lightingModel = .physicallyBased
        material.isDoubleSided = true
        material.diffuse.contentsTransform = SCNMatrix4Translate(SCNMatrix4MakeScale(1, -1, 1), 0, 1, 0)
        material.roughness.contents = 0.6
        material.metalness.contents = 0.9
        material.selfIllumination.contents = 0.7
        return material
    }
    public func createTextShape(string: String, size: CGFloat) -> SCNText{
        let text = SCNText(string: string, extrusionDepth: 0.1)
        text.font =  UIFont(name: "Avenir-Black", size: size)
        text.flatness = 0
        text.chamferRadius = 0.05
        return text 
    }
    public func createTextMaterial(particleName: String) -> SCNMaterial{
        let textMaterial = SCNMaterial()
        let particleDictionary = staticDictionary.getParticle(name: particleName)
        textMaterial.diffuse.contents = particleDictionary?["color"] as! UIColor
        textMaterial.specular.contents = UIColor.white
        textMaterial.metalness.contents = 0.9
        textMaterial.roughness.contents = 0.3
        textMaterial.selfIllumination.contents = 0.5
        textMaterial.lightingModel = .physicallyBased
        return textMaterial
    }
    public func createLighting(node: SCNNode) {
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light?.type = SCNLight.LightType.directional
        lightNode.light?.color = UIColor.white
        lightNode.light?.castsShadow = true
        
        lightNode.light?.shadowSampleCount = 64
        lightNode.light?.shadowRadius = 16
        lightNode.light?.shadowMode = .deferred
        lightNode.light?.shadowMapSize = CGSize(width: 2048, height: 2048)
        lightNode.light?.shadowColor = UIColor.black.withAlphaComponent(0.5)
        lightNode.position = SCNVector3(x: 0,y: 4,z: 0.2)
        lightNode.eulerAngles = SCNVector3(-Float.pi / 2, 0, 0)
        
        node.addChildNode(lightNode)
    }
    
    public func createLabel(string: String, size: CGFloat, color: UIColor, position: CGPoint) -> SKLabelNode {
        let label = SKLabelNode(fontNamed: "Avenir-Black")
        label.fontSize = size
        label.fontColor = color
        label.horizontalAlignmentMode = .center
        label.verticalAlignmentMode = .center
        label.position = position
        label.text = String.uppercased(string)()
        return label
    }
    public func fadeAnimation(node: SCNNode) {
        let duration: TimeInterval = 1
        let emit = SCNAction.customAction(duration: 1, action: {node, elapsedTime in 
            let percentage = elapsedTime / CGFloat(duration)
            node.geometry?.firstMaterial?.emission.contents = percentage * 0.5
        })
        let wait = SCNAction.wait(duration: 1)
        let unemit = SCNAction.customAction(duration: 1, action: {node, elapsedTime in 
            let percentage = 0.5 - ((elapsedTime / CGFloat(duration)) / 2)
            node.geometry?.firstMaterial?.emission.contents = percentage
        })
        let emitSequence = SCNAction.sequence([emit, wait, unemit])
        node.runAction(emitSequence)
    }
    public func createArrow(isRepel: Bool) -> SCNNode {
        let arrowNode = SCNNode()
        let cone = SCNCone(topRadius: 0.0, bottomRadius: 0.008, height: 0.02)
        let coneNode = SCNNode(geometry: cone)
        coneNode.localTranslate(by: SCNVector3Make(0.014, 0, 0))
        coneNode.eulerAngles.z = -.pi/2
        
        let cylinder = SCNCylinder(radius: 0.004, height: 0.03)
        let cylinderNode = SCNNode(geometry: cylinder)
        cylinderNode.localTranslate(by: SCNVector3Make(-0.009, 0, 0))
        cylinderNode.eulerAngles.z = -.pi/2
        
        arrowNode.addChildNode(coneNode)
        arrowNode.addChildNode(cylinderNode)
        if isRepel == false {
            arrowNode.eulerAngles.z = .pi
        }
        
        let flatArrowNode = arrowNode.flattenedClone()
        flatArrowNode.geometry?.materials = [createArrowMaterial()]
        flatArrowNode.castsShadow = false
        flatArrowNode.name = "arrow"
        return flatArrowNode
    }
    
        public func createArrowMaterial() -> SCNMaterial {
            let material = SCNMaterial()
            material.lightingModel = .physicallyBased
            material.isDoubleSided = true
            material.diffuse.contents = UIColor.green
            material.roughness.contents = 0.3
            material.metalness.contents = 0.9
            material.selfIllumination.contents = 0.7
            material.transparency = 0.8
            return material
    }
    public func animateArrow(duration: TimeInterval, distance: Float, isRepel: Bool) -> SCNAction {
        let leftAction = SCNAction.move(by: SCNVector3Make(-0.05, 0, 0), duration: duration)
        let leftBackPosition = SCNAction.move(by: SCNVector3Make(0.05, 0.0, 0.0), duration: 0)
        let leftSequence = SCNAction.sequence([
            leftAction, 
            leftBackPosition
        ])
        
        let rightAction = SCNAction.move(by: SCNVector3Make(0.05, 0, 0), duration: duration)
        let rightBackPosition = SCNAction.move(by: SCNVector3Make(-0.05, 0.0, 0.0), duration: 0)
        let rightSequence = SCNAction.sequence([
            rightAction, 
            rightBackPosition
        ])
        
        var moveLoop: SCNAction!
        
        if isRepel == true {
            moveLoop = SCNAction.repeatForever(rightSequence)
        } else {
            moveLoop = SCNAction.repeatForever(leftSequence)
        }
        return moveLoop
    }
    public func fadeIn(duration: TimeInterval, isRepel: Bool) -> SCNAction {
        let fadeIn = SCNAction.customAction(duration: duration, action: {node, elapsedTime in 
            let percentage = elapsedTime / CGFloat(duration)
            node.geometry?.firstMaterial?.transparency = (percentage * 0.5)
        })
        
        let fadeInR = SCNAction.customAction(duration: duration, action: {node, elapsedTime in 
            let percentage = elapsedTime / CGFloat(duration)
            node.geometry?.firstMaterial?.transparency = 0.5 - (percentage * 0.5)
        })
        
        var moveLoop: SCNAction!
        
        if isRepel == true {
            moveLoop = SCNAction.repeatForever(fadeInR)
        } else {
            moveLoop = SCNAction.repeatForever(fadeIn)
        }
        
        return moveLoop
    }
    public func secondFadeIn(duration: TimeInterval, isRepel: Bool) -> SCNAction {
        let fadeIn = SCNAction.customAction(duration: duration, action: {node, elapsedTime in 
            let percentage = elapsedTime / CGFloat(duration)
            node.geometry?.firstMaterial?.transparency = ((percentage * 0.3) + 0.5)
        })
        
        let fadeInR = SCNAction.customAction(duration: duration, action: {node, elapsedTime in 
                let percentage = elapsedTime / CGFloat(duration)
                node.geometry?.firstMaterial?.transparency = 0.8 - (percentage * 0.3)
            })
        
        var moveLoop: SCNAction!
        
        if isRepel == true {
            moveLoop = SCNAction.repeatForever(fadeInR)
        } else {
            moveLoop = SCNAction.repeatForever(fadeIn)
        }
        return moveLoop
    }
        public func fadeOut(duration: TimeInterval, isRepel: Bool) -> SCNAction {
            let fadeOut = SCNAction.customAction(duration: duration, action: {node, elapsedTime in 
                let percentage = elapsedTime / CGFloat(duration)
                node.geometry?.firstMaterial?.transparency = 0.8 - (percentage * 0.8)
            })
            
            let fadeOutR = SCNAction.customAction(duration: duration, action: {node, elapsedTime in 
                    let percentage = elapsedTime / CGFloat(duration)
                    node.geometry?.firstMaterial?.transparency = (percentage * 0.8)
                })
            
            var moveLoop: SCNAction!
            
            if isRepel == true {
                moveLoop = SCNAction.repeatForever(fadeOutR)
            } else {
                moveLoop = SCNAction.repeatForever(fadeOut)
            }
            
            return moveLoop
        }
        public func fade(duration: TimeInterval) -> SCNAction {
            var fade = SCNAction.customAction(duration: duration, action: {node, elapsedTime in 
                node.geometry?.firstMaterial?.transparency = 0.5
            })
            
            let moveLoop = SCNAction.repeatForever(fade)
            return moveLoop
        }
    public func qFadeIn(node: SCNNode) {
        let duration: TimeInterval = 1
        let fadeIn = SCNAction.customAction(duration: 1, action: {node, elapsedTime in 
            let percentage = elapsedTime / CGFloat(duration)
            node.opacity = percentage
        })
        node.runAction(fadeIn)
        
        node.runAction(SCNAction.sequence([fadeIn]))
    }
    public func qFadeOut(node: SCNNode) {
        let duration: TimeInterval = 1
        let fadeOut = SCNAction.customAction(duration: 1, action: {node, elapsedTime in 
            let percentage = elapsedTime / CGFloat(duration)
            node.opacity = 1 - percentage
        })
        node.runAction(SCNAction.sequence([fadeOut]))
    }
    }
    
    
    


