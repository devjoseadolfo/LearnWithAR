
import UIKit
import SceneKit

public enum Element: String {
    case hydrogen = "hydrogen"
    case helium = "helium"
    case lithium = "lithium"
    case beryllium = "beryllium"
    case boron = "boron"
    case carbon = "carbon"
    case nitrogen = "nitrogen"
    case oxygen = "oxygen"
    case fluorine = "fluorine"
    case neon = "neon"
}

var sphereCoordinatesA: Dictionary<String, SCNVector3> = [
    "A1": SCNVector3Make(-0.03, 0.03265986, -0.028867513),
    "A2": SCNVector3Make(0.01, 0.03265986, -0.028867513),
    "A3": SCNVector3Make(-0.01, 0.03265986, 0.005773502),
    "A4": SCNVector3Make(0.03, 0.03265986, 0.005773502),
    "A5": SCNVector3Make(0.01, 0.03265986, 0.040414518),
    
    "B1": SCNVector3Make(-0.03, 0.0, -0.051961524),
    "B2": SCNVector3Make(0.01, 0.0, -0.051961524),
    "B3": SCNVector3Make(-0.05, 0.0, -0.017320508),
    "B4": SCNVector3Make(-0.01, 0.0, -0.017320508),
    "B5": SCNVector3Make(0.03, 0.0, -0.017320508),
    "B6": SCNVector3Make(-0.03, 0.0, 0.017320508),
    "B7": SCNVector3Make(0.01, 0.0, 0.017320508),
    "B8": SCNVector3Make(0.05, 0.0, 0.017320508),
    "B9": SCNVector3Make(-0.01, 0.0, 0.051961524),
    "B10": SCNVector3Make(0.03, 0.0, 0.051961524),
    
    "C1": SCNVector3Make(-0.01, -0.03265986, -0.040414518),
    "C2": SCNVector3Make(-0.03, -0.03265986, -0.005773502),
    "C3": SCNVector3Make(0.01, -0.03265986, -0.005773502), 
    "C4": SCNVector3Make(-0.01, -0.03265986, 0.028867513),
    "C5": SCNVector3Make(0.03, -0.03265986, 0.028867513)
]

var sphereCoordinatesB: Dictionary<String, SCNVector3> = [
    "A3": SCNVector3Make(-0.02, 0.03265986, -0.005773502),
    "A4": SCNVector3Make(0.02, 0.03265986, -0.005773502),
    
    "B4": SCNVector3Make(-0.02, 0.0, -0.034641016),
    "B5": SCNVector3Make(0.02, 0.0, -0.034641016),
    "B6": SCNVector3Make(-0.04, 0.0, 0.0),
    "B7": SCNVector3Make(0.00, 0.0, 0.0),
    "B8": SCNVector3Make(0.04, 0.0, 0.0),
    "B9": SCNVector3Make(-0.02, 0.0, 0.034641016),
    "B10": SCNVector3Make(0.02, 0.0, 0.034641016),
    
    "C3": SCNVector3Make(0.00, -0.03265986, -0.015700538), 
    "C4": SCNVector3Make(-0.02, -0.03265986, 0.005773502),
    "C5": SCNVector3Make(0.02, -0.03265986, 0.005773502)
]
var particle: Dictionary<String, Dictionary<String, Any>> = [
    "electron": electron,
    "proton": proton,
    "neutron": neutron
]

var electron: Dictionary<String, Any> = [
    "color": UIColor.systemBlue,
    "P3color": UIColor.systemBlue,
    "size": CGFloat(0.010)
]

var proton: Dictionary<String, Any> = [
    "color": UIColor.init(red: 230/255, green: 15/255, blue: 15/255, alpha: 1.0),
    "P3color": UIColor.red,
    "size": CGFloat(0.02)
]

var neutron: Dictionary<String, Any> = [
    "color": UIColor(red: 1.0, green: 0.7, blue: 0.0, alpha: 1.0),
    "P3color": UIColor.yellow,
    "size": CGFloat(0.02)
]

var element: Dictionary<String, Dictionary<String, Any>> = [
    "hydrogen": hydrogen,
    "helium": helium,
    "lithium": lithium,
    "beryllium": beryllium,
    "boron": boron,
    "carbon": carbon,
    "nitrogen": nitrogen,
    "oxygen": oxygen,
    "fluorine": fluorine,
    "neon": neon
]

var hydrogen: Dictionary<String, Any> = [
    "name": "hydrogen",
    "symbol": "H",
    "proton": 1,
    "neutron": 0,
    "electron": 1,
    "isDefault": false,
    "protonPositions": ["B7"],
]

var helium: Dictionary<String, Any> = [
    "name": "helium",
    "symbol": "He",
    "proton": 2,
    "neutron": 2,
    "electron": 2,
    "isDefault": true,
    "protonPositions": ["B7", "C3"],
    "neutronPositions": ["A3", "B4"],
]

var lithium: Dictionary<String, Any> = [
    "name": "lithium",
    "symbol": "Li",
    "proton": 3,
    "neutron": 4,
    "electron": 3,
    "isDefault": true,
    "protonPositions": ["A2", "B5", "B6"],
    "neutronPositions": ["B4", "B7", "C3", "C4"],
]

var beryllium: Dictionary<String, Any> = [
    "name": "beryllium",
    "symbol": "Be",
    "proton": 4,
    "neutron": 5,
    "electron": 4,
    "isDefault": true,
    "protonPositions": ["A4", "B4", "B8", "C2"],
    "neutronPositions": ["A3", "B5", "B6", "B7", "C3"],
]

var boron: Dictionary<String, Any> = [
    "name": "boron",
    "symbol": "B",
    "proton": 5,
    "neutron": 6,
    "electron": 5,
    "isDefault": false,
    "protonPositions": ["A4", "B5", "B7", "B9", "C5"],
    "neutronPositions": ["A3", "B4", "B6", "B8", "C3", "C4"],
]

var carbon: Dictionary<String, Any> = [
    "name": "carbon",
    "symbol": "C",
    "proton": 6,
    "neutron": 6,
    "electron": 6,
    "isDefault": false,
    "protonPositions": ["A4", "B5", "B6", "B7", "B10", "C5"],
    "neutronPositions": ["A3", "B4", "B8", "B9", "C3" ,"C4"]
]

var nitrogen: Dictionary<String, Any> = [
    "name": "nitrogen",
    "symbol": "N",
    "proton": 7,
    "neutron": 7,
    "electron": 7,
    "isDefault": true,
    "protonPositions": ["A2", "A4", "B3", "B4", "B9", "C3", "C4"],
    "neutronPositions": ["A3", "B2", "B5", "B6", "B7", "B8", "C2"],
]

var oxygen: Dictionary<String, Any> = [
    "name": "oxygen",
    "symbol": "O",
    "proton": 8,
    "neutron": 8,
    "electron": 8,
    "isDefault": true,
    "protonPositions": ["A4", "B3", "B4", "B5", "B6", "B8", "B10", "C4"],
    "neutronPositions": ["A2", "A3", "B1", "B2", "B7", "B9", "C2", "C3"],
]

var fluorine: Dictionary<String, Any> = [
    "name": "fluorine",
    "symbol": "F",
    "proton": 9,
    "neutron": 10,
    "electron": 9,
    "isDefault": true,
    "protonPositions": ["A4", "A5", "B1", "B4", "B5", "B6", "B7", "C2", "C5"],
    "neutronPositions": ["A2", "A3", "B2", "B3", "B8", "B9", "B10", "C1", "C3", "C4"],
]

var neon: Dictionary<String, Any> = [
    "name": "neon",
    "symbol": "Ne",
    "proton": 10,
    "neutron": 10,
    "electron": 10,
    "isDefault": true,
    "protonPositions": ["A2", "A3", "A5", "B1", "B4", "B7", "B8", "B9", "C2", "C4"],
    "neutronPositions": ["A1", "A4", "B2", "B3", "B5", "B6", "B10", "C1", "C3", "C5"],
]

public class staticDictionary {
    public init(){
    }
    public static func getParticle(name: String) -> Dictionary<String, Any>? {
        return particle[name]
    }
    public static func getElement(name: String) -> Dictionary<String, Any>?{
        return element[name]
    }
    public static func getCoordinates(isDefault: Bool, code: String) -> SCNVector3?{
        if isDefault == true {
            return sphereCoordinatesA[code]
        } else {
            return sphereCoordinatesB[code]
        }
    }
}
